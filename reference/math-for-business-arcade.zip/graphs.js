/* ===== Gr: a tiny SVG grapher used for explanations and tutorials =====
   Gr.render(spec) returns an HTML string (<figure> with an inline <svg> and a legend row).
   spec = {
     curves:[{f, label, color:0-3, dash, x0, x1}]   f(x) -> y   (NaN breaks the line)
             or {param:{x:t=>, y:t=>, t0, t1}, label, color}
     pts:[{x,y,label,pos:'tr'|'tl'|'br'|'bl',color,open}]
     segs:[{x1,y1,x2,y2,label,dash,color}]
     vlines:[{x,label}], hlines:[{y,label}]
     fills:[{f,g,x0,x1,color}]                       shaded area between two curves
     xr:[min,max], yr:[min,max]  (optional: chosen automatically)
     equal:true  same scale on both axes (perpendicular lines, inverses)
     xlab, ylab, caption
   }  Colours are categorical slots 1-3 (blue, orange, aqua) plus neutral ink for slot 4. */
const Gr=(()=>{
 let uid=0;
 const COL=['var(--c1)','var(--c2)','var(--c3)','var(--ink)'];
 const W=560,H=360,ML=46,MR=18,MT=16,MB=34,PW=W-ML-MR,PH=H-MT-MB;
 const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
 const strip=s=>String(s).replace(/<sup>(.*?)<\/sup>/g,'^$1').replace(/<[^>]+>/g,'');
 const num=v=>Math.round(v*100)/100;
 function niceStep(span,target){const raw=span/target;const p=Math.pow(10,Math.floor(Math.log10(raw)));const f=raw/p;return (f<1.5?1:f<3.5?2:f<7.5?5:10)*p;}
 function tickLabel(v){v=Math.abs(v)<1e-9?0:Math.round(v*1e6)/1e6;let s=Math.abs(v)>=10000?(v/1000)+'k':String(v);return s.replace('-','−');}
 function sampleCurve(c,xa,xb,n){const out=[];
  if(c.param){const p=c.param;for(let i=0;i<=n;i++){const t=p.t0+(p.t1-p.t0)*i/n;out.push([p.x(t),p.y(t)]);}return out;}
  const a=c.x0!=null?Math.max(c.x0,xa):xa,b=c.x1!=null?Math.min(c.x1,xb):xb;if(b<a)return out;
  for(let i=0;i<=n;i++){const x=a+(b-a)*i/n;let y;try{y=c.f(x);}catch(e){y=NaN;}out.push([x,y]);}return out;}
 function ranges(s){
  const kx=[0],ky=[0];
  (s.pts||[]).forEach(p=>{kx.push(p.x);ky.push(p.y);});
  (s.segs||[]).forEach(g=>{kx.push(g.x1,g.x2);ky.push(g.y1,g.y2);});
  (s.vlines||[]).forEach(v=>kx.push(v.x));(s.hlines||[]).forEach(h=>ky.push(h.y));
  (s.fills||[]).forEach(f=>{kx.push(f.x0,f.x1);});
  (s.curves||[]).forEach(c=>{if(c.x0!=null)kx.push(c.x0);if(c.x1!=null)kx.push(c.x1);});
  let xmin=Math.min(...kx),xmax=Math.max(...kx);
  if(xmax-xmin<4){const m=(xmax+xmin)/2;xmin=m-2;xmax=m+2;}
  const px=(xmax-xmin)*0.22;xmin-=px;xmax+=px;if(s.xr){xmin=s.xr[0];xmax=s.xr[1];}
  let ymin,ymax;
  if(s.yr){ymin=s.yr[0];ymax=s.yr[1];}
  else{const ys=[];(s.curves||[]).forEach(c=>sampleCurve(c,xmin,xmax,200).forEach(p=>{if(isFinite(p[1])&&Math.abs(p[1])<1e6)ys.push(p[1]);}));
   ys.sort((a,b)=>a-b);let lo=0,hi=0;if(ys.length){const k=Math.floor(ys.length*0.03);lo=ys[Math.min(k,ys.length-1)];hi=ys[Math.max(ys.length-1-k,0)];}
   ymin=Math.min(lo,...ky);ymax=Math.max(hi,...ky);if(ymax-ymin<2){const m=(ymax+ymin)/2;ymin=m-1;ymax=m+1;}
   const py=(ymax-ymin)*0.12;ymin-=py;ymax+=py;}
  if(s.equal){const sx=PW/(xmax-xmin),sy=PH/(ymax-ymin),sc=Math.min(sx,sy);const nx=PW/sc,ny=PH/sc;const cx=(xmin+xmax)/2,cy=(ymin+ymax)/2;xmin=cx-nx/2;xmax=cx+nx/2;ymin=cy-ny/2;ymax=cy+ny/2;}
  return {xmin,xmax,ymin,ymax};}
 function render(s){
  const id='gc'+(++uid);const R=ranges(s);const {xmin,xmax,ymin,ymax}=R;
  const X=x=>ML+(x-xmin)/(xmax-xmin)*PW,Y=y=>MT+(ymax-y)/(ymax-ymin)*PH;
  const f2=v=>(Math.round(v*10)/10).toString();
  let g='';
  const sx=niceStep(xmax-xmin,s.equal?7:7),sy=niceStep(ymax-ymin,s.equal?sx*0+6:6);
  const xs=[],ys=[];for(let v=Math.ceil(xmin/sx)*sx;v<=xmax+1e-9;v+=sx)xs.push(Math.round(v/sx)*sx);for(let v=Math.ceil(ymin/sy)*sy;v<=ymax+1e-9;v+=sy)ys.push(Math.round(v/sy)*sy);
  const ax=xmin<=0&&xmax>=0?X(0):(xmin>0?ML:ML+PW),ay=ymin<=0&&ymax>=0?Y(0):(ymin>0?MT+PH:MT);
  xs.forEach(v=>{g+=`<line class="g-grid" x1="${f2(X(v))}" y1="${MT}" x2="${f2(X(v))}" y2="${MT+PH}"/>`;});
  ys.forEach(v=>{g+=`<line class="g-grid" x1="${ML}" y1="${f2(Y(v))}" x2="${ML+PW}" y2="${f2(Y(v))}"/>`;});
  g+=`<line class="g-axis" x1="${ML}" y1="${f2(ay)}" x2="${ML+PW}" y2="${f2(ay)}"/><line class="g-axis" x1="${f2(ax)}" y1="${MT}" x2="${f2(ax)}" y2="${MT+PH}"/>`;
  xs.forEach(v=>{if(Math.abs(v)<1e-9&&ax>ML&&ax<ML+PW)return;const ty=Math.min(Math.max(ay+14,MT+12),MT+PH+14);g+=`<text class="g-tick" x="${f2(X(v))}" y="${f2(ty)}" text-anchor="middle">${tickLabel(v)}</text>`;});
  ys.forEach(v=>{if(Math.abs(v)<1e-9)return;const tx=Math.min(Math.max(ax-6,ML-4),ML+PW);const anchor='end';g+=`<text class="g-tick" x="${f2(tx<ML?ML-6:tx)}" y="${f2(Y(v)+4)}" text-anchor="${anchor}">${tickLabel(v)}</text>`;});
  g+=`<text class="g-axl" x="${ML+PW-2}" y="${f2(Math.min(ay-6,MT+PH-6))}" text-anchor="end">${esc(s.xlab||'x')}</text><text class="g-axl" x="${f2(Math.min(ax+8,ML+PW-10))}" y="${MT+12}">${esc(s.ylab||'y')}</text>`;
  /* clipped content */
  let c='';
  (s.fills||[]).forEach(fl=>{const a=Math.max(fl.x0,xmin),b=Math.min(fl.x1,xmax);const top=[],bot=[];for(let i=0;i<=60;i++){const x=a+(b-a)*i/60;top.push([x,fl.f(x)]);bot.push([x,fl.g(x)]);}
   const pts=top.concat(bot.reverse()).filter(p=>isFinite(p[0])&&isFinite(p[1])).map(p=>f2(X(p[0]))+','+f2(Y(p[1]))).join(' ');c+=`<polygon points="${pts}" fill="${COL[fl.color||0]}" opacity="0.14"/>`;});
  (s.vlines||[]).forEach(v=>{c+=`<line class="g-ref" x1="${f2(X(v.x))}" y1="${MT}" x2="${f2(X(v.x))}" y2="${MT+PH}"/>`;});
  (s.hlines||[]).forEach(h=>{c+=`<line class="g-ref" x1="${ML}" y1="${f2(Y(h.y))}" x2="${ML+PW}" y2="${f2(Y(h.y))}"/>`;});
  (s.segs||[]).forEach(sg=>{c+=`<line x1="${f2(X(sg.x1))}" y1="${f2(Y(sg.y1))}" x2="${f2(X(sg.x2))}" y2="${f2(Y(sg.y2))}" stroke="${COL[sg.color==null?3:sg.color]}" stroke-width="${sg.dash===false?2.5:1.6}" ${sg.dash===false?'':'stroke-dasharray="5 4"'} />`;});
  (s.curves||[]).forEach(cu=>{const pts=sampleCurve(cu,xmin,xmax,320);const span=ymax-ymin;let d='',pen=false,prev=null;
   pts.forEach(p=>{const ok=isFinite(p[0])&&isFinite(p[1])&&Math.abs(p[1])<1e6;if(!ok){pen=false;prev=null;return;}
    if(prev&&Math.abs(p[1]-prev[1])>span*1.5&&!cu.param){pen=false;}
    d+=(pen?'L':'M')+f2(X(p[0]))+' '+f2(Y(p[1]));pen=true;prev=p;});
   const dash=cu.dash===true?'7 5':cu.dash==='dot'?'2 5':'';c+=`<path d="${d}" fill="none" stroke="${COL[cu.color||0]}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" ${dash?`stroke-dasharray="${dash}"`:''}/>`;});
  g+=`<clipPath id="${id}"><rect x="${ML}" y="${MT}" width="${PW}" height="${PH}"/></clipPath><g clip-path="url(#${id})">${c}</g>`;
  /* labels over the clip */
  (s.segs||[]).forEach(sg=>{if(!sg.label)return;const mx=X((sg.x1+sg.x2)/2),my=Y((sg.y1+sg.y2)/2);const vert=Math.abs(sg.x1-sg.x2)<1e-9;g+=`<text class="g-lab" x="${f2(mx+(vert?8:0))}" y="${f2(my+(vert?4:-6))}" text-anchor="${vert?'start':'middle'}">${esc(strip(sg.label))}</text>`;});
  (s.vlines||[]).forEach(v=>{if(!v.label)return;g+=`<text class="g-lab" x="${f2(X(v.x)+6)}" y="${MT+26}">${esc(strip(v.label))}</text>`;});
  (s.hlines||[]).forEach(h=>{if(!h.label)return;g+=`<text class="g-lab" x="${ML+PW-4}" y="${f2(Y(h.y)-6)}" text-anchor="end">${esc(strip(h.label))}</text>`;});
  (s.pts||[]).forEach(p=>{if(p.x<xmin||p.x>xmax||p.y<ymin||p.y>ymax)return;const cx=X(p.x),cy=Y(p.y);
   g+=`<circle cx="${f2(cx)}" cy="${f2(cy)}" r="5.5" fill="${p.open?'var(--card)':COL[p.color==null?3:p.color]}" stroke="${p.open?COL[p.color==null?3:p.color]:'var(--card)'}" stroke-width="2"/>`;
   if(p.label){const lab=esc(strip(p.label));const wd=lab.length*6.6;let pos=p.pos||(cx>ML+PW*0.7?'tl':'tr');if(cy<MT+24&&pos[0]==='t')pos='b'+pos[1];if(cy>MT+PH-24&&pos[0]==='b')pos='t'+pos[1];
    const right=pos[1]==='r';let tx=right?cx+9:cx-9;if(right&&tx+wd>W-4)pos=pos[0]+'l';const anc=pos[1]==='r'&&tx+wd<=W-4?'start':'end';tx=anc==='start'?cx+9:cx-9;const ty=pos[0]==='t'?cy-9:cy+17;
    g+=`<text class="g-lab" x="${f2(tx)}" y="${f2(ty)}" text-anchor="${anc}">${lab}</text>`;}});
  const leg=(s.curves||[]).filter(cu=>cu.label).map(cu=>`<span class="g-key"><svg width="26" height="10" aria-hidden="true"><line x1="1" y1="5" x2="25" y2="5" stroke="${COL[cu.color||0]}" stroke-width="3" stroke-linecap="round" ${cu.dash===true?'stroke-dasharray="6 4"':cu.dash==='dot'?'stroke-dasharray="2 4"':''}/></svg>${cu.label}</span>`).join('');
  const alt=esc(strip(s.alt||s.caption||(s.curves||[]).map(c=>c.label||'').filter(Boolean).join(', ')||'Graph'));
  return `<figure class="graph"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${alt}" preserveAspectRatio="xMidYMid meet">${g}</svg>${leg?`<figcaption class="g-legend">${leg}</figcaption>`:''}${s.caption?`<div class="g-cap">${s.caption}</div>`:''}</figure>`;}
 return {render,ranges};
})();
/* short builders */
const cv=(f,label,color=0,o={})=>Object.assign({f,label,color},o);
const pt=(x,y,label,o={})=>Object.assign({x,y,label},o);
const sg=(x1,y1,x2,y2,o={})=>Object.assign({x1,y1,x2,y2},o);
const LN=(m,b)=>x=>m*x+b;
const withG=(r,g)=>{r.graph=g;return r;};
const yEq=(m,b)=>'y = '+poly([[m,1],[b,0]]);
/* guide lines from a point to both axes */
const drop=(x,y)=>[sg(x,0,x,y),sg(0,y,x,y)];
