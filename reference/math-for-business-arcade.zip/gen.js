/* ===== Typed-answer support =====
   A "fill" question has a template: strings are shown as text, numbers (or {v,d,tol,c}) are answer boxes.
   {v} value, {d} how to display the correct answer, {tol} absolute tolerance, {c:true} a count box that also accepts ∞. */
function fmtNum(v){if(v===Infinity)return'∞';if(Number.isInteger(v))return M(v);for(let d=2;d<=200;d++){const n=v*d;if(Math.abs(n-Math.round(n))<1e-9)return frac(Math.round(n),d);}return M(Math.round(v*10000)/10000);}
function fill(q,tpl,e,opts={}){const fields=[];const t=tpl.map(x=>{if(typeof x==='string')return x;const f=typeof x==='number'?{v:x}:Object.assign({},x);if(f.sel){f.kind='sel';f.v=f.sel;f.d=f.sel;}else if(f.set){f.kind='set';f.v=f.set[0];f.d=f.set.map(fmtNum).join(', ');}if(f.d==null)f.d=fmtNum(f.v);fields.push(f);return f;});
 let correct='';t.forEach((x,ix)=>{if(typeof x==='string'){correct+=x;return;}const nx=t[ix+1];let d=x.d;if(/\+ $/.test(correct)&&d.startsWith('−')){correct=correct.replace(/\+ $/,'− ');d=d.slice(1);}const dec=(!x.kind&&(nx===undefined||/^[\s,.;]/.test(nx))&&!x.noalt&&isFinite(x.v)&&!Number.isInteger(x.v)&&/\//.test(d)&&!/[√^]/.test(d))?` <span class="alt">(≈ ${M(Math.round(x.v*1000)/1000)})</span>`:'';correct+=`<b>${d}</b>${dec}`;});return{kind:'fill',q,tpl:t,fields,correct,e,any:!!opts.any};}
/* Safe arithmetic evaluator: + − × ÷ ^ ( ) √ sqrt(), fractions, decimals with . or , and implicit 2√3 */
function evalInput(raw,count){if(raw==null)return NaN;let s=String(raw).trim().toLowerCase();if(!s)return NaN;
 if(count&&/^(∞|inf|infinity|infinite|infinitely many|many|infinitely)$/.test(s))return Infinity;
 s=s.replace(/[−–—]/g,'-').replace(/[×·]/g,'*').replace(/÷/g,'/').replace(/\$|€|\s|units?/g,'').replace(/sqrt/g,'√');
 if(/^-?\d{1,3}(,\d{3})+(\.\d+)?$/.test(s))s=s.replace(/,/g,'');else s=s.replace(/,/g,'.');
 let i=0;const peek=()=>s[i];
 function num(){const m=/^\d*\.?\d+/.exec(s.slice(i));if(!m)throw 0;i+=m[0].length;return parseFloat(m[0]);}
 function atom(){const c=peek();if(c==='('){i++;const v=expr();if(peek()!==')')throw 0;i++;return v;}if(c==='√'){i++;const v=power();if(v<0)throw 0;return Math.sqrt(v);}return num();}
 function power(){let b=atom();if(peek()==='^'){i++;const e=factor();b=Math.pow(b,e);}return b;}
 function factor(){const c=peek();if(c==='-'){i++;return -factor();}if(c==='+'){i++;return factor();}return power();}
 function term(){let v=factor();for(;;){const c=peek();if(c==='*'){i++;v*=factor();}else if(c==='/'){i++;v/=factor();}else if(c==='√'||c==='('){v*=power();}else break;}return v;}
 function expr(){let v=term();for(;;){const c=peek();if(c==='+'){i++;v+=term();}else if(c==='-'){i++;v-=term();}else break;}return v;}
 try{const v=expr();if(i!==s.length)return NaN;return v;}catch(e){return NaN;}}
function closeTo(x,f){if(!isFinite(x)||!isFinite(f.v))return x===f.v;const tol=f.tol!=null?f.tol:(Number.isInteger(f.v)?1e-9:Math.max(0.0051,Math.abs(f.v)*0.002));return Math.abs(x-f.v)<=tol;}
/* returns array of booleans, one per field */
function parseSet(raw){let s=String(raw||'').toLowerCase().replace(/\b[xy]\s*=\s*/g,'').replace(/[−–—]/g,'-');return s.split(/\s*(?:;|,\s+|\s+(?:or|and)\s+|,(?=-))\s*/).map(t=>t.trim()).filter(Boolean);}
function setOK(f,raw){let toks=parseSet(raw);if(toks.length!==f.set.length&&/,/.test(raw))toks=String(raw).split(',').map(t=>t.trim()).filter(Boolean);
 if(toks.length!==f.set.length)return false;const used=new Array(f.set.length).fill(false);
 return toks.every(t=>{const v=evalInput(t);const k=f.set.findIndex((w,j)=>!used[j]&&closeTo(v,{v:w}));if(k<0)return false;used[k]=true;return true;});}
function badInput(f,s){if(f.kind==='sel')return !s;if(f.kind==='set'){const t=parseSet(s);return !t.length||t.some(x=>isNaN(evalInput(x)));}return isNaN(evalInput(s,f.c));}
function checkFill(q,inputs){
 if(!q.any||q.fields.some(f=>f.kind))return q.fields.map((f,k)=>f.kind==='sel'?inputs[k]===f.v:f.kind==='set'?setOK(f,inputs[k]):closeTo(evalInput(inputs[k],f.c),f));
 const vals=inputs.map((s,k)=>evalInput(s,q.fields[k].c));
 const used=new Array(q.fields.length).fill(false);return vals.map(v=>{const k=q.fields.findIndex((f,j)=>!used[j]&&closeTo(v,f));if(k<0)return false;used[k]=true;return true;});}

/* ===== Randomized question generators =====
   Calculations are typed answers (fill). Multiple choice is kept only for terms and concepts. */
const GENS=[];
let _g=null;const G=sp=>{_g=sp;};
const gen=(t,g,fn)=>GENS.push({t,g,fn:()=>{_g=null;const r=fn();if(_g&&!r.graph)r.graph=_g;_g=null;return r;}});
const qf=(a,b,c)=>x=>a*x*x+b*x+c;
const expG=(L,R,cap)=>({curves:[cv(L,'one side (before)',0),cv(R,'other side (after)',1,{dash:true})],caption:cap||'The two curves lie exactly on top of each other: before and after are the same function.'});
const parG=(a,b,c,o={})=>{const D=b*b-4*a*c,pts=[];
 if(o.roots!==false&&D>=0){const sq=Math.sqrt(D);const rs=[...new Set([(-b-sq)/(2*a),(-b+sq)/(2*a)].map(r=>Math.round(r*1e6)/1e6))].sort((p,q)=>p-q);
  rs.forEach((r,i)=>pts.push(pt(r,0,`(${fmtNum(r)}, 0)`,{color:1,pos:(a>0?'b':'t')+(rs.length>1&&i===0?'l':'r')})));}
 const h=-b/(2*a),k=a*h*h+b*h+c;
 if(o.vertex)pts.push(pt(h,k,`vertex (${fmtNum(h)}, ${fmtNum(k)})`,{color:2,pos:(a>0?'b':'t')+(h>=0?'r':'l')}));
 if(o.yint)pts.push(pt(0,c,`(0, ${M(c)})`,{color:2,pos:'tr'}));
 const cap=o.cap||(o.roots===false?'':(D>0?'The parabola crosses the x-axis twice: two real roots.':D===0?'The parabola just touches the x-axis: one real root.':'The parabola never reaches the x-axis: no real roots.'));
 return {curves:[cv(qf(a,b,c),'y = '+poly([[a,2],[b,1],[c,0]]),0)],pts,caption:cap};};
const lin2=(m,b,lab,col=0,o={})=>cv(x=>m*x+b,lab||yEq(m,b),col,o);
const co=a=>a===1?'':a===-1?'−':M(a);

/* ---- Algebra ---- */
gen('alg','props',()=>{const a=rnd(2,9),b=rnd(2,9),c=rnd(2,9);const items=[
 [`${a} + ${b} = ${b} + ${a}`,'Commutative property of addition','Only the <b>order</b> changes.'],
 [`${a} · ${b} = ${b} · ${a}`,'Commutative property of multiplication','Only the <b>order</b> of the factors changes.'],
 [`(${a} · ${b}) · ${c} = ${a} · (${b} · ${c})`,'Associative property of multiplication','Only the <b>grouping</b> changes.'],
 [`(${a} + ${b}) + ${c} = ${a} + (${b} + ${c})`,'Associative property of addition','Only the <b>grouping</b> changes.'],
 [`${a}(x + ${b}) = ${a}x + ${a*b}`,'Distributive property','The factor outside multiplies each term inside.'],
 [`${a} + 0 = ${a}`,'Identity property','Adding 0 (additive identity) leaves the number unchanged.'],
 [`${a} · (1/${a}) = 1`,'Inverse property','1/a is the multiplicative inverse of a.'],
 [`${a} + (−${a}) = 0`,'Inverse property','−a is the additive inverse of a.']];
 const [ex,ans,why]=pick(items);
 return {q:`Which property is shown?<div class="big">${ex}</div>`,o:mcq(ans,shuffle(['Commutative property of addition','Commutative property of multiplication','Associative property of addition','Associative property of multiplication','Distributive property','Identity property','Inverse property','Transitive property'])),e:why};});

gen('alg','exp',()=>{const a=rnd(2,7),b=rnd(2,6);const t=pick(['mul','pow','div']);
 if(t==='mul')G(Object.assign(expG(x=>x**a*x**b,x=>x**(a+b),'x^'+a+' · x^'+b+' and x^'+(a+b)+' are the same curve, so the rule is just a shortcut.'),{xr:[0,2],yr:[0,16]}));else if(t==='pow')G(Object.assign(expG(x=>(x**a)**b,x=>x**(a*b),'(x^'+a+')^'+b+' and x^'+(a*b)+' trace exactly the same curve.'),{xr:[0,2],yr:[0,16]}));else G(Object.assign(expG(x=>x**(a+b)/x**b,x=>x**a,'x^'+(a+b)+' / x^'+b+' and x^'+a+' are the same curve (for x ≠ 0).'),{xr:[0,2],yr:[0,16]}));
 
 if(t==='mul')return fill(`Simplify x${sup(a)} · x${sup(b)}`,['x^',a+b],`Same base, multiplying → <b>add</b> the exponents: x${sup(a)}·x${sup(b)} = x${sup(a+'+'+b)} = x${sup(a+b)}.`);
 if(t==='pow')return fill(`Simplify (x${sup(a)})${sup(b)}`,['x^',a*b],`Power of a power → <b>multiply</b> the exponents: (x${sup(a)})${sup(b)} = x${sup(a+'·'+b)} = x${sup(a*b)}.`);
 const top=a+b;return fill(`Simplify x${sup(top)} / x${sup(b)}`,['x^',a],`Same base, dividing → <b>subtract</b> the exponents: x${sup(top+'−'+b)} = x${sup(a)}.`);});

gen('alg','exp',()=>{const n=rnd(2,6),m=rnd(2,6);G(Object.assign(expG(x=>x**-n,x=>1/x**n,'x^(−'+n+') and 1/x^'+n+' are the same curve (for x > 0): it is positive and falls toward 0, never negative.'),{xr:[0.4,3],yr:[0,8]}));
 return fill(`Write without negative exponents: x${sup('−'+n)}y${sup(m)}`,['y^',m,'  /  x^',n],`x${sup('−n')} = 1/x${sup('n')}. So x${sup('−'+n)}y${sup(m)} = y${sup(m)}/x${sup(n)}. A negative exponent means “move to the other side of the fraction bar”, not “make it negative”.`);});

gen('alg','exp',()=>{const k=rnd(2,6),m=pick([2,3,5,6,7]),n=k*k*m;G({curves:[cv(Math.sqrt,'y = √x',0,{x0:0})],pts:[pt(n,Math.sqrt(n),`(${n}, ≈${(Math.round(Math.sqrt(n)*100)/100)})`,{color:1,pos:'bl'})],xr:[0,n*1.25],caption:`√${n} ≈ ${(Math.round(Math.sqrt(n)*100)/100)} is the height of the curve at x = ${n}, and ${k}√${m} has exactly the same value.`});
 return fill(`Simplify √${n} completely`,['',k,' √',m],`Find the largest perfect square factor: ${n} = ${k*k} · ${m}. Then √${n} = √${k*k} · √${m} = ${k}√${m}.`);});

gen('alg','exp',()=>{const b=pick([2,3,4,5]),r=pick([2,3]),n=b**r;const word=r===2?'√':'∛';G({curves:[cv(x=>Math.pow(x,1/r),'y = x'+(r===2?'^½':'^⅓'),0,{x0:0})],pts:[pt(n,b,`(${n}, ${b})`,{color:1,pos:'br'})],xr:[0,n*1.3],caption:`At x = ${n} the curve is at height ${b}, so ${n}^(1/${r}) = ${b}.`});
 return fill(`Evaluate ${n}${sup('1/'+r)}`,['',b],`x${sup('1/n')} = ⁿ√x. So ${n}${sup('1/'+r)} = ${word}${n} = ${b}, because ${b}${sup(r)} = ${n}.`);});

gen('alg','prod',()=>{const a=rnd(1,9);const t=pick(['sq+','sq-','diff','two']);const T=(b,c)=>['x² + ',b,'x + ',c];
 if(t!=='two'){const Lf={'sq+':x=>(x+a)**2,'sq-':x=>(x-a)**2,diff:x=>(x+a)*(x-a)}[t],Rf={'sq+':x=>x*x+2*a*x+a*a,'sq-':x=>x*x-2*a*x+a*a,diff:x=>x*x-a*a}[t];G(Object.assign(expG(Lf,Rf,'The factored form and the expanded form give the very same parabola, so they are equal for every x.'),{xr:[-a-4,a+4],yr:[-a*a-4,(a+4)**2+4]}));}
 if(t==='sq+')return fill(`Expand (x + ${a})${sup(2)}`,T(2*a,a*a),`(x + a)² = x² + 2ax + a². With a = ${a}: x² + ${2*a}x + ${a*a}. Don't forget the middle term!`);
 if(t==='sq-')return fill(`Expand (x − ${a})${sup(2)}`,T(-2*a,a*a),`(x − a)² = x² − 2ax + a². With a = ${a}: x² − ${2*a}x + ${a*a}. The last term is positive because (−${a})² = ${a*a}.`);
 if(t==='diff')return fill(`Expand (x + ${a})(x − ${a})`,T(0,-a*a),`(x + a)(x − a) = x² − a² (difference of squares). The middle terms +${a}x and −${a}x cancel, so the x-coefficient is 0.`);
 const b=nz(-9,9);G(Object.assign(expG(x=>(x+a)*(x+b),x=>x*x+(a+b)*x+a*b,'The factored form and the expanded form give the very same parabola, so they are equal for every x.'),{xr:[-Math.abs(a)-Math.abs(b)-3,Math.abs(a)+Math.abs(b)+3]}));
 return fill(`Expand (x + ${a})(x ${b<0?'−':'+'} ${Math.abs(b)})`,T(a+b,a*b),`(x + a)(x + b) = x² + (a + b)x + ab. Here a + b = ${M(a+b)} and ab = ${M(a*b)}.`);});

gen('alg','prod',()=>{const t=pick(['diff','tri']);const T=(r,s)=>['(x + ',r,')(x + ',s,')'];
 if(t==='diff'){const k=rnd(2,9);G(parG(1,0,-k*k));
 return fill(`Factor x${sup(2)} − ${k*k}`,T(k,-k),`Difference of squares: x² − a² = (x − a)(x + a). ${k*k} = ${k}², so a = ${k}: (x − ${k})(x + ${k}).`,{any:true});}
 let r=nz(-7,7),s=nz(-7,7);if(r===-s)s=s+1||2;const f=v=>`(x ${v<0?'−':'+'} ${Math.abs(v)})`;
 G(parG(1,r+s,r*s,{cap:`The curve crosses the x-axis at x = ${M(-r)} and x = ${M(-s)}: exactly where each bracket is zero.`}));
 return fill(`Factor ${poly([[1,2],[r+s,1],[r*s,0]])}`,T(r,s),`Find two numbers that multiply to ${M(r*s)} and add to ${M(r+s)}: they are ${M(r)} and ${M(s)}. So the expression is ${f(r)}${f(s)}.`,{any:true});});

gen('alg','frac',()=>{const m=pick([2,3,5,6,7]),t=rnd(2,5),k=m*t;return fill(`Rationalize the denominator and simplify: ${k}/√${m}`,['',t,' √',m],`Multiply top and bottom by √${m}: ${k}√${m}/${m} = ${t}√${m}.`);});

gen('alg','frac',()=>{const a=rnd(1,5),b=rnd(1,5);let c=rnd(2,6),d=rnd(2,6);if(c===d)d++;const num=a*d+b*c,den=c*d;return fill(`Add: ${a}/${c} + ${b}/${d}`,['',num/den],`Common denominator ${c}·${d} = ${den}: ${a*d}/${den} + ${b*c}/${den} = ${num}/${den}${gcd(num,den)>1?' = '+frac(num,den):''}. Never add denominators.`);});

gen('alg','lineq',()=>{const x0=rnd(-8,8);let a=rnd(2,9),c=rnd(1,8);if(a===c)a++;const b=rnd(-12,12),d=a*x0+b-c*x0;G({curves:[lin2(a,b,'left side: y = '+poly([[a,1],[b,0]]),0),lin2(c,d,'right side: y = '+poly([[c,1],[d,0]]),1)],pts:[pt(x0,a*x0+b,`x = ${M(x0)}`,{color:2})],xlab:'x',ylab:'side',caption:'Solving the equation means finding where the two sides are equal: the x-coordinate where the lines meet.'});
 return fill(`Solve for x: ${a}x${b?sgn(b):''} = ${c===1?'':c}x${d?sgn(d):''}`,['x = ',x0],`Move x-terms left and constants right: ${a}x − ${c}x = ${M(d)} − ${P(b)} → ${a-c}x = ${M(d-b)} → x = ${M(x0)}.<br>Check: ${a}(${M(x0)})${sgn(b)} = ${M(a*x0+b)} and ${c}(${M(x0)})${sgn(d)} = ${M(c*x0+d)} ✓`);});

gen('alg','lineq',()=>{const c=pick([2,3,4,6]),q=rnd(1,6),a=c*q,b=nz(-6,6);const x0=q-b;G({curves:[cv(x=>a/(x+b),`y = ${a}/(x${sgn(b)})`,0),cv(()=>c,`y = ${c}`,1)],vlines:[{x:-b,label:`x = ${M(-b)} (not allowed)`}],pts:[pt(x0,c,`x = ${M(x0)}`,{color:2})],yr:[-3*c,4*c],caption:'The curve is not defined at the dashed line (denominator zero). The solution is where the curve reaches the height '+c+'.'});
 return fill(`Solve the fractional equation: ${a}/(x${sgn(b)}) = ${c}`,['x = ',x0],`Multiply both sides by (x${sgn(b)}): ${a} = ${c}(x${sgn(b)}) → ${a/c} = x${sgn(b)} → x = ${M(x0)}. Check it doesn't make the denominator zero: ${M(x0)}${sgn(b)} = ${a/c} ≠ 0 ✓`);});

gen('alg','lineq',()=>{const t=pick(['I','S','y','ab']);
 if(t==='I'){const P=pick([500,1000,2000,4000]),r=pick([2,3,4,5,6]),tt=pick([2,3,4,5]);const I=P*r*tt/100;return fill(`Literal equation: solve I = Prt for r, then find r when I = ${I}, P = ${P}, t = ${tt}. (Give r as a decimal.)`,['r = ',{v:r/100,d:''+(r/100)}],`Divide both sides by Pt: r = I/(Pt) = ${I}/(${P}·${tt}) = ${I}/${P*tt} = ${r/100} (that's ${r}%).`);}
 if(t==='S'){const P=pick([1000,2000,5000]),r=pick([4,5,8,10]),tt=pick([2,3,4,5]);const S=P*(1+r*tt/100);return fill(`Literal equation: solve S = P(1 + rt) for t, then find t when S = ${S}, P = ${P}, r = ${r/100}.`,['t = ',tt],`S/P = 1 + rt → S/P − 1 = rt → t = (S − P)/(Pr) = (${S} − ${P})/(${P}·${r/100}) = ${S-P}/${P*r/100} = ${tt}.`);}
 if(t==='y'){const m=nz(-5,5),x=rnd(-6,6),b=rnd(-9,9),y=m*x+b;return fill(`Literal equation: solve y = mx + b for x, then find x when y = ${M(y)}, m = ${M(m)}, b = ${M(b)}.`,['x = ',x],`x = (y − b)/m = (${M(y)} − ${P(b)})/${P(m)} = ${M(y-b)}/${P(m)} = ${M(x)}.`);}
 let a=rnd(1,6),c=rnd(1,8);if(a===c)c++;const x=rnd(-5,5)||2,b=(c-a)*x;return fill(`Literal equation: solve ax + b = cx for x, then find x when a = ${a}, b = ${M(b)}, c = ${c}.`,['x = ',x],`Collect x-terms: b = cx − ax = (c − a)x, so x = b/(c − a) = ${M(b)}/${c-a} = ${M(x)}.`);});

gen('alg','quad',()=>{const r1=rnd(-8,8);let r2=rnd(-8,8);if(r2===r1)r2=r1+rnd(1,4);const b=-(r1+r2),c=r1*r2;
 G(parG(1,b,c,{cap:'The solutions of the equation are the points where the parabola meets the x-axis (y = 0).'}));
 return fill(`Solve by factoring: ${poly([[1,2],[b,1],[c,0]])} = 0`,['Solutions: ',{set:[r1,r2]}],`Need two numbers with product ${M(c)} and sum ${M(b)}: ${M(-r1)} and ${M(-r2)}. So (x ${-r1<0?'−':'+'} ${Math.abs(r1)})(x ${-r2<0?'−':'+'} ${Math.abs(r2)}) = 0, and by the zero-product rule x = ${M(r1)} or x = ${M(r2)}.`.replace(/\(x [+−] 0\)/g,'x'),{any:true});});

gen('alg','quad',()=>{let a,b,c;const kind=pick([0,1,2]);
 if(kind===1){const p=rnd(1,4),q=nz(-5,5);a=p*p;b=2*p*q;c=q*q;}
 else if(kind===2){a=rnd(1,4);const r1=rnd(-5,5),r2=r1+rnd(1,5);b=-a*(r1+r2);c=a*r1*r2;}
 else{a=rnd(1,4);b=rnd(-4,4);c=Math.floor(b*b/(4*a))+rnd(1,6);}
 const D=b*b-4*a*c,n=D>0?2:D===0?1:0;
 G(parG(a,b,c));
 return fill(`For ${poly([[a,2],[b,1],[c,0]])} = 0, find the discriminant and the number of real roots.`,['b² − 4ac = ',D,'     number of real roots = ',n],`Discriminant b² − 4ac = ${P(b)}² − 4(${a})(${P(c)}) = ${b*b} − ${4*a*c} = ${M(D)}. ${D>0?'Positive → two real roots.':D===0?'Zero → one real root.':'Negative → no real roots (√ of a negative).'}`);});

gen('alg','quad',()=>{const a=pick([1,2]);const r1=rnd(-6,6),r2=r1+pick([2,4,6]);const b=-a*(r1+r2),c=a*r1*r2,D=b*b-4*a*c;
 G(parG(a,b,c,{cap:'The two solutions of the formula are where the parabola meets the x-axis.'}));
 return fill(`Use the quadratic formula: ${poly([[a,2],[b,1],[c,0]])} = 0`,['Solutions: ',{set:[r1,r2]}],`x = (−b ± √(b² − 4ac)) / 2a = (${M(-b)} ± √${D}) / ${2*a} = (${M(-b)} ± ${Math.sqrt(D)}) / ${2*a}. So x = ${M(r2)} or x = ${M(r1)}.`,{any:true});});

/* ---- Functions ---- */
gen('fun','func',()=>{const a=nz(-4,4),b=rnd(-6,6),c=rnd(-9,9),k=rnd(-4,4);const v=a*k*k+b*k+c;G({curves:[cv(qf(a,b,c),'f(x) = '+poly([[a,2],[b,1],[c,0]]),0)],pts:[pt(k,v,`f(${M(k)}) = ${M(v)}`,{color:1})],segs:drop(k,v),caption:`Input ${M(k)} on the x-axis goes up to the curve and across to the output ${M(v)} on the y-axis.`});
 return fill(`f(x) = ${poly([[a,2],[b,1],[c,0]])}. Find f(${M(k)}).`,[`f(${M(k)}) = `,v],`Substitute x = ${M(k)}: ${co(a)}(${M(k)})² ${b<0?'−':'+'} ${Math.abs(b)}(${M(k)}) ${c<0?'−':'+'} ${Math.abs(c)} = ${a*k*k} ${b*k<0?'−':'+'} ${Math.abs(b*k)} ${c<0?'−':'+'} ${Math.abs(c)} = ${M(v)}. Square first, then multiply: (${M(k)})² = ${k*k}.`);});

gen('fun','func',()=>{const t=pick(['rat','rat2','sqrt']);const k=nz(-9,9);
 if(t==='rat')G({curves:[cv(x=>5/(x-k),`f(x) = 5/(x ${k<0?'+':'−'} ${Math.abs(k)})`,0)],vlines:[{x:k,label:`x = ${M(k)}`}],yr:[-15,15],xr:[k-8,k+8],caption:'The graph never touches the dashed line: that input is excluded from the domain.'});else if(t==='rat2'){const a=Math.abs(k);G({curves:[cv(x=>x/(x*x-a*a),'f(x) = x/(x² − '+(a*a)+')',0)],vlines:[{x:a,label:'x = '+a},{x:-a,label:'x = −'+a}],xr:[-a*2.4,a*2.4],yr:[-4/a,4/a],caption:'There are two breaks, one at each excluded value.'});}else G({curves:[cv(x=>Math.sqrt(x-k),`f(x) = √(x ${k<0?'+':'−'} ${Math.abs(k)})`,0,{x0:k})],pts:[pt(k,0,`starts at x = ${M(k)}`,{color:1,pos:'tr'})],xr:[k-4,k+10],yr:[-1,4],caption:'The graph exists only for x ≥ '+M(k)+': nothing is drawn to the left of the start point.'});
 
 if(t==='rat')return fill(`Find the domain of f(x) = 5/(x ${k<0?'+':'−'} ${Math.abs(k)})`,['Excluded x-value: ',{set:[k]}],`A denominator can't be zero: x ${k<0?'+':'−'} ${Math.abs(k)} = 0 when x = ${M(k)}. Everything else is allowed.`);
 if(t==='rat2'){const a=Math.abs(k);return fill(`Find the domain of f(x) = x/(x${sup(2)} − ${a*a})`,['Excluded x-values: ',{set:[a,-a]}],`x² − ${a*a} = (x − ${a})(x + ${a}) = 0 at x = ±${a}. Exclude both.`,{any:true});}
 return fill(`Find the domain of f(x) = √(x ${k<0?'+':'−'} ${Math.abs(k)})`,['x ',{sel:'≥'},' ',k],`A square root needs a radicand ≥ 0: x ${k<0?'+':'−'} ${Math.abs(k)} ≥ 0 → x ≥ ${M(k)}. (x = ${M(k)} is fine: √0 = 0.)`);});

gen('fun','special',()=>{const t=pick(['fact','fact2','abs','piece','const']);
 if(t==='fact'){const n=rnd(3,6);let f=1;for(let i=2;i<=n;i++)f*=i;return fill(`Compute ${n}!`,[`${n}! = `,f],`${n}! = ${Array.from({length:n},(_,i)=>i+1).join(' · ')} = ${f}.`);}
 if(t==='fact2'){const n=rnd(5,10);return fill(`Compute ${n}!/${n-2}!`,['',n*(n-1)],`${n}! = ${n}·${n-1}·${n-2}!, so the ${n-2}! cancels: ${n}·${n-1} = ${n*(n-1)}.`);}
 if(t==='abs'){const a=rnd(-9,9),b=rnd(-9,9);const v=Math.abs(a-b);G({curves:[cv(x=>Math.abs(x-b),`f(x) = |x ${b<0?'+':'−'} ${Math.abs(b)}|`,0)],pts:[pt(a,v,`f(${M(a)}) = ${v}`,{color:1}),pt(b,0,`corner (${M(b)}, 0)`,{color:2,pos:'br'})],caption:'Absolute value makes a V shape: the output is never below zero.'});
 return fill(`Let f(x) = |x ${b<0?'+':'−'} ${Math.abs(b)}|. Find f(${M(a)}).`,[`f(${M(a)}) = `,v],`f(${M(a)}) = |${M(a)} ${b<0?'+':'−'} ${Math.abs(b)}| = |${M(a-b)}| = ${v}. Absolute value is never negative.`);}
 if(t==='const'){const c=nz(-9,9),k=rnd(-20,20);G({curves:[cv(()=>c,`h(x) = ${M(c)}`,0)],pts:[pt(k,c,`h(${M(k)}) = ${M(c)}`,{color:1})],xr:[Math.min(-5,k-3),Math.max(5,k+3)],caption:'A constant function is a flat horizontal line: every input gives the same output.'});
 return fill(`h(x) = ${M(c)} for all x. Find h(${M(k)}).`,[`h(${M(k)}) = `,c],`A constant function gives the same output for every input: h(${M(k)}) = ${M(c)}.`);}
 const k=rnd(-2,3),x=rnd(-4,5),a=rnd(2,4),b=rnd(1,6);const v=x<k?a*x+b:x*x;
 G({curves:[cv(x=>a*x+b,`${a}x + ${b}  (x < ${M(k)})`,0,{x1:k}),cv(x=>x*x,`x²  (x ≥ ${M(k)})`,1,{x0:k})],pts:[pt(k,a*k+b,'',{color:0,open:true}),pt(k,k*k,'',{color:1}),pt(x,v,`f(${M(x)}) = ${M(v)}`,{color:2,pos:'tl'})],xr:[Math.min(-4,k-3,x-2),Math.max(5,k+3,x+2)],caption:'The open dot means that end is not included. Which piece you read depends on where x sits relative to '+M(k)+'.'});
 return fill(`f(x) = ${a}x + ${b} if x < ${M(k)}, and f(x) = x${sup(2)} if x ≥ ${M(k)}. Find f(${M(x)}).`,[`f(${M(x)}) = `,v],`${M(x)} ${x<k?'<':'≥'} ${M(k)}, so use ${x<k?`${a}x + ${b}: ${a}(${M(x)}) + ${b} = ${M(v)}`:`x²: (${M(x)})² = ${v}`}. Always pick the rule first, then substitute.`);});

gen('fun','combo',()=>{const a=nz(-5,5),b=rnd(-6,6),k=rnd(-3,3),c=rnd(-4,4);const f=a*k+b,g=k*k+c;const op=pick(['+','−','·']);const v=op==='+'?f+g:op==='−'?f-g:f*g;const name=op==='+'?'(f + g)':op==='−'?'(f − g)':'(fg)';
 {const F=x=>a*x+b,Gg=x=>x*x+c,R=op==='+'?x=>F(x)+Gg(x):op==='−'?x=>F(x)-Gg(x):x=>F(x)*Gg(x);G({curves:[cv(F,'f(x) = '+poly([[a,1],[b,0]]),0),cv(Gg,'g(x) = '+poly([[1,2],[c,0]]),1),cv(R,name.replace('(','').replace(')','')+'(x) = f '+op+' g',2,{dash:true})],pts:[pt(k,v,`${name}(${M(k)}) = ${M(v)}`,{color:2,pos:'tr'})],xr:[-6,6],caption:'The dashed curve is built point by point from the other two: at each x, combine the heights of f and g.'});}
 return fill(`f(x) = ${poly([[a,1],[b,0]])} and g(x) = ${poly([[1,2],[c,0]])}. Find ${name}(${M(k)}).`,[`${name}(${M(k)}) = `,v],`f(${M(k)}) = ${M(f)}, g(${M(k)}) = ${M(g)}. ${name}(${M(k)}) = ${P(f)} ${op} ${P(g)} = ${M(v)}.`);});

gen('fun','combo',()=>{const a=nz(-4,4),b=rnd(-6,6),c=nz(-4,4),d=rnd(-6,6);const order=pick(['fg','gf']);
 const lbl=order==='fg'?'(f ∘ g)(x)':'(g ∘ f)(x)';const m=a*c,k=order==='fg'?a*d+b:c*b+d;
 const e=order==='fg'?`(f∘g)(x) = f(g(x)) = ${co(a)}(${poly([[c,1],[d,0]])})${b?sgn(b):''} = ${poly([[m,1],[k,0]])}. Put g inside f.`:`(g∘f)(x) = g(f(x)) = ${co(c)}(${poly([[a,1],[b,0]])})${d?sgn(d):''} = ${poly([[m,1],[k,0]])}. Put f inside g.`;
 {const F=x=>a*x+b,Gg=x=>c*x+d,R=order==='fg'?x=>F(Gg(x)):x=>Gg(F(x));G({curves:[cv(F,'f(x) = '+poly([[a,1],[b,0]]),0),cv(Gg,'g(x) = '+poly([[c,1],[d,0]]),1),cv(R,lbl+' = '+poly([[m,1],[k,0]]),2,{dash:true})],caption:'The composition is yet another line: feeding one line into the other gives a new slope and intercept. Order matters, so f∘g and g∘f are different lines.'});}
 return fill(`f(x) = ${poly([[a,1],[b,0]])} and g(x) = ${poly([[c,1],[d,0]])}. Find ${lbl}.`,[`${lbl} = `,m,'x + ',k],e);});

gen('fun','combo',()=>{const a=nz(-4,4),b=rnd(-5,5),c=nz(-3,3),d=rnd(-5,5),k=rnd(-3,3);const g=c*k+d,v=a*g+b;G({curves:[cv(x=>a*x+b,'f(x) = '+poly([[a,1],[b,0]]),0),cv(x=>c*x+d,'g(x) = '+poly([[c,1],[d,0]]),1)],pts:[pt(k,g,`g(${M(k)}) = ${M(g)}`,{color:1,pos:'tl'}),pt(g,v,`f(${M(g)}) = ${M(v)}`,{color:0,pos:'br'})],caption:'Step 1: read g at the first input. Step 2: use that output as the new input of f.'});
 return fill(`f(x) = ${poly([[a,1],[b,0]])}, g(x) = ${poly([[c,1],[d,0]])}. Find f(g(${M(k)})).`,[`f(g(${M(k)})) = `,v],`Inside first: g(${M(k)}) = ${M(g)}. Then f(${M(g)}) = ${M(a)}(${M(g)})${b?sgn(b):''} = ${M(v)}.`);});

gen('fun','inverse',()=>{const a=pick([-5,-4,-3,-2,2,3,4,5]),b=nz(-9,9);const B=b<0?`+ ${-b}`:`− ${b}`;G({curves:[cv(x=>a*x+b,'f(x) = '+poly([[a,1],[b,0]]),0),cv(x=>x/a-b/a,'f⁻¹(x)',1),cv(x=>x,'y = x (mirror)',3,{dash:true})],equal:true,xr:[-8,8],yr:[-8,8],caption:'The inverse is the mirror image of f in the dashed line y = x: every point (p, q) on f becomes (q, p).'});
 return fill(`Find the inverse of f(x) = ${poly([[a,1],[b,0]])}. Write it as f⁻¹(x) = mx + c (fractions are fine).`,['f⁻¹(x) = ',1/a,'x + ',-b/a],`Write y = ${poly([[a,1],[b,0]])}, swap x and y: x = ${poly([[a,1],[b,0]],'y')}. Solve for y: y = (x ${B})/${P(a)} = ${fmtNum(1/a)}x ${-b/a<0?'− '+fmtNum(b/a):'+ '+fmtNum(-b/a)}. Undo the steps in reverse order: first undo “${b<0?'−':'+'} ${Math.abs(b)}”, then undo “× ${P(a)}”.`);});

gen('fun','inverse',()=>{const a=nz(-5,5),b=rnd(-9,9),x0=rnd(-5,5),k=a*x0+b;G({curves:[cv(x=>a*x+b,'f(x) = '+poly([[a,1],[b,0]]),0),cv(x=>x/a-b/a,'f⁻¹(x)',1),cv(x=>x,'y = x',3,{dash:true})],pts:[pt(x0,k,`f(${M(x0)}) = ${M(k)}`,{color:0,pos:'tl'}),pt(k,x0,`f⁻¹(${M(k)}) = ${M(x0)}`,{color:1,pos:'br'})],equal:true,xr:[-10,10],yr:[-10,10],caption:'The point (x, k) on f swaps to (k, x) on f⁻¹.'});
 return fill(`f(x) = ${poly([[a,1],[b,0]])}. Find f⁻¹(${M(k)}).`,[`f⁻¹(${M(k)}) = `,x0],`f⁻¹(${M(k)}) is the x with f(x) = ${M(k)}: ${poly([[a,1],[b,0]])} = ${M(k)} → ${co(a)}x = ${M(k-b)} → x = ${M(x0)}.`);});

gen('fun','graph',()=>{const m=nz(-5,5),x0=nz(-6,6),b=-m*x0;G({curves:[cv(x=>m*x+b,'y = '+poly([[m,1],[b,0]]),0)],pts:[pt(x0,0,`x-intercept (${M(x0)}, 0)`,{color:1,pos:'tr'}),pt(0,b,`y-intercept (0, ${M(b)})`,{color:2,pos:'tr'})],caption:'Intercepts are where the graph crosses the axes: set y = 0 for the x-intercept, set x = 0 for the y-intercept.'});
 return fill(`Find the intercepts of y = ${poly([[m,1],[b,0]])}.`,['x-intercept (',x0,', 0)      y-intercept (0, ',b,')'],`y-intercept: set x = 0 → y = ${M(b)}. x-intercept: set y = 0 → ${poly([[m,1],[b,0]])} = 0 → x = ${M(x0)}.`);});

gen('fun','graph',()=>{const c=rnd(1,6);const items=[
 [`y = x${sup(2)} + ${c}`,'y-axis only','Replacing x by −x: (−x)² + '+c+' = x² + '+c+' ✓ equivalent. Replacing y by −y changes the equation ✗.'],
 [`y = x${sup(4)} − ${c}x${sup(2)}`,'y-axis only','Only even powers of x, so x → −x gives the same equation.'],
 [`y = x${sup(3)}`,'Origin only','x → −x and y → −y: −y = −x³ → y = x³ ✓. But x → −x alone gives y = −x³ ✗.'],
 [`y = ${c}x`,'Origin only','−y = '+c+'(−x) → y = '+c+'x ✓ for origin. Not y-axis (gives y = −'+c+'x).'],
 [`x = y${sup(2)}`,'x-axis only','y → −y: x = (−y)² = y² ✓. x → −x gives −x = y² ✗.'],
 [`y = x${sup(3)} + ${c}`,'None of these','The constant +'+c+' breaks origin symmetry: −y = −x³ + '+c+' is not equivalent. Odd power breaks y-axis symmetry.'],
 [`x${sup(2)} + y${sup(2)} = ${c*c}`,'x-axis, y-axis and origin','Every variable is squared, so any sign change gives an equivalent equation (it\'s a circle).']];
 const [eq,ans,why]=pick(items);{const i=items.findIndex(z=>z[0]===eq);const CV=[cv(x=>x*x+c,'',0),cv(x=>x**4-c*x*x,'',0),cv(x=>x**3,'',0),cv(x=>c*x,'',0),{param:{x:t=>t*t,y:t=>t,t0:-3,t1:3},color:0},cv(x=>x**3+c,'',0),{param:{x:t=>c*Math.cos(t),y:t=>c*Math.sin(t),t0:0,t1:2*Math.PI},color:0}][i];CV.label=eq.replace(/<\/?sup>/g,'');const R=i===6?c+1.5:5;G({curves:[CV],equal:i===6,xr:[-R,R],yr:i===6?[-R,R]:[-8,10],caption:'Fold the picture along the axis (or turn it half a turn about the origin) and check whether it lands on itself. Symmetry: '+ans+'.'});}
 return{q:`Which symmetry does the graph of ${eq} have?`,o:mcq(ans,shuffle(['y-axis only','x-axis only','Origin only','None of these','x-axis, y-axis and origin'])),e:why};});

gen('fun','trans',()=>{const h=nz(-5,5),k=nz(-5,5);const base=pick([['x'+sup(2),'x²'],['x'+sup(3),'x³'],['|x|','|x|'],['√x','√x']]);
 const inner=base[1]==='√x'?`√(x ${h<0?'+':'−'} ${Math.abs(h)})`:base[1]==='|x|'?`|x ${h<0?'+':'−'} ${Math.abs(h)}|`:`(x ${h<0?'+':'−'} ${Math.abs(h)})${sup(base[1]==='x²'?2:3)}`;
 {const BF={'x²':x=>x*x,'x³':x=>x**3,'|x|':Math.abs,'√x':x=>x>=0?Math.sqrt(x):NaN}[base[1]];G({curves:[cv(BF,'y = '+base[0],3,{dash:true}),cv(x=>BF(x-h)+k,'y = '+inner+' '+(k<0?'−':'+')+' '+Math.abs(k),1)],pts:[pt(0,0,'',{color:3,open:true}),pt(h,k,`moved to (${M(h)}, ${M(k)})`,{color:1,pos:h>=0?'br':'bl'})],xr:[Math.min(-4,h-4),Math.max(4,h+4)],yr:[Math.min(-4,k-3),Math.max(6,k+7)],caption:'Dashed: the original graph. Solid: the shifted one. Every point moves '+Math.abs(h)+' '+(h>=0?'right':'left')+' and '+Math.abs(k)+' '+(k>=0?'up':'down')+'.'});}
 return fill(`y = ${inner} ${k<0?'−':'+'} ${Math.abs(k)} is y = ${base[0]} shifted how far? (Right and up are positive; use a negative number for left or down.)`,['right ',h,'      up ',k],`y = f(x − c) moves the graph c units right (c < 0 means left); y = f(x) + c moves it up. Here the inside shift is ${M(h)} (${h>0?'right':'left'} ${Math.abs(h)}) and the outside is ${M(k)} (${k>0?'up':'down'} ${Math.abs(k)}).`);});

gen('fun','trans',()=>{const items=[['y = −f(x)','Reflect about the x-axis','Multiplying the output by −1 flips the graph upside down.'],['y = f(−x)','Reflect about the y-axis','Replacing x with −x flips the graph left–right.'],['y = 2f(x)','Stretch vertically by a factor of 2','Every output doubles.'],['y = ½f(x)','Shrink vertically by a factor of 2','Every output is halved.']];const [eq,ans,why]=pick(items);
{const F=x=>(x-1)**2+1;const T=[x=>-F(x),x=>F(-x),x=>2*F(x),x=>F(x)/2][items.findIndex(z=>z[0]===eq)];G({curves:[cv(F,'y = f(x)',3,{dash:true}),cv(T,eq,1)],xr:[-5,5],yr:[-10,12],caption:'Dashed: the original f(x) = (x − 1)² + 1 (an example function). Solid: after the transformation.'});}
  return{q:`What does ${eq} do to the graph of y = f(x)?`,o:mcq(ans,shuffle(items.map(i=>i[1]).concat(['Shift 1 unit right']))),e:why};});

/* ---- Lines, parabolas, systems ---- */
gen('lin','lines',()=>{let x1=rnd(-6,6),y1=rnd(-6,6),x2=rnd(-6,6),y2=rnd(-6,6);if(x1===x2)x2=x1+rnd(1,4);const dy=y2-y1,dx=x2-x1;{const mm=dy/dx;G({curves:[cv(x=>y1+mm*(x-x1),'slope m = '+frac(dy,dx),0)],pts:[pt(x1,y1,`(${M(x1)}, ${M(y1)})`,{color:1,pos:'tl'}),pt(x2,y2,`(${M(x2)}, ${M(y2)})`,{color:1,pos:'br'})],segs:[sg(x1,y1,x2,y1,{label:'run '+M(dx),color:2}),sg(x2,y1,x2,y2,{label:'rise '+M(dy),color:2})],caption:'Slope = rise ÷ run, measured between the two points.'});}
 return fill(`Find the slope of the line through (${M(x1)}, ${M(y1)}) and (${M(x2)}, ${M(y2)}).`,['m = ',dy/dx],`m = (y₂ − y₁)/(x₂ − x₁) = (${M(y2)} − ${P(y1)})/(${M(x2)} − ${P(x1)}) = ${M(dy)}/${M(dx)} = ${frac(dy,dx)}. Rise over run, y on top.`);});

gen('lin','lines',()=>{const m=nz(-5,5),x1=rnd(-5,5),y1=rnd(-6,6),b=y1-m*x1;G({curves:[cv(x=>m*x+b,'y = '+poly([[m,1],[b,0]]),0)],pts:[pt(x1,y1,`(${M(x1)}, ${M(y1)})`,{color:1,pos:'tr'}),pt(0,b,`y-intercept ${M(b)}`,{color:2,pos:'tl'})],caption:'The line passes through the given point and has the given slope. Where it crosses the y-axis is the constant b.'});
 return fill(`Find the line with slope ${M(m)} through (${M(x1)}, ${M(y1)}), in slope-intercept form.`,['y = ',m,'x + ',b],`Point-slope: y − ${P(y1)} = ${M(m)}(x − ${P(x1)}). Expand: y = ${M(m)}x ${-m*x1<0?'−':'+'} ${Math.abs(m*x1)} ${y1<0?'−':'+'} ${Math.abs(y1)} = ${poly([[m,1],[b,0]])}.`);});

gen('lin','lines',()=>{const A=nz(-6,6),B=nz(-6,6),C=rnd(-9,9);const lhs=`${poly([[A,1]])} ${B<0?'−':'+'} ${Math.abs(B)===1?'':Math.abs(B)}y${C?` ${C<0?'−':'+'} ${Math.abs(C)}`:''}`;
 G({curves:[cv(x=>(-A*x-C)/B,'y = '+frac(-A,B)+'x + '+frac(-C,B),0)],pts:[pt(0,-C/B,`y-intercept ${frac(-C,B)}`,{color:2,pos:'tr'})],caption:'Slope = '+frac(-A,B)+' ('+((-A/B)>0?'rising':'falling')+' to the right). Intercept = where the line meets the y-axis.'});
 return fill(`Find the slope and y-intercept of ${lhs} = 0`,['slope = ',-A/B,'      y-intercept = ',-C/B],`Solve for y: ${co(B)}y = ${poly([[-A,1],[-C,0]])} → y = ${frac(-A,B)}x + ${frac(-C,B)}. Slope = −A/B = ${frac(-A,B)}, intercept = −C/B = ${frac(-C,B)}.`);});

gen('lin','parperp',()=>{const n=nz(-6,6),d=pick([1,1,2,3]);const m=frac(n,d);const t=pick(['par','perp']);
 G({curves:[cv(x=>(n/d)*x+4,`y = ${m}x + 4`,0),t==='par'?cv(x=>(n/d)*x-3,'a parallel line (same slope)',1):cv(x=>(-d/n)*x+4,'a perpendicular line',1)],equal:t==='perp',xr:[-8,8],yr:[-8,8],caption:t==='par'?'Parallel lines have the same slope, so they never meet.':'Perpendicular lines meet at a right angle; their slopes multiply to −1.'});
 return t==='par'?fill(`A line is parallel to y = ${m}x + 4. What is its slope?`,['m = ',n/d],`Parallel lines have the <b>same</b> slope: ${m}.`)
 :fill(`A line is perpendicular to y = ${m}x + 4. What is its slope?`,['m = ',-d/n],`Perpendicular slopes are negative reciprocals: m₂ = −1/m₁ = −1/(${m}) = ${frac(-d,n)}. Check: (${m})(${frac(-d,n)}) = −1.`);});

gen('lin','parperp',()=>{const m=nz(-4,4),x1=rnd(-4,4),y1=rnd(-5,5);const t=pick(['par','perp']);
 if(t==='par'){const b=y1-m*x1;G({curves:[cv(x=>m*x+7,'given: y = '+poly([[m,1],[7,0]]),0),cv(x=>m*x+b,'new: y = '+poly([[m,1],[b,0]]),1)],pts:[pt(x1,y1,`(${M(x1)}, ${M(y1)})`,{color:2,pos:'tr'})],caption:'Same slope, so the new line is a copy of the given line shifted to pass through your point.'});
 return fill(`Find the line through (${M(x1)}, ${M(y1)}) parallel to y = ${poly([[m,1],[7,0]])}.`,['y = ',m,'x + ',b],`Same slope ${M(m)}. y − ${P(y1)} = ${M(m)}(x − ${P(x1)}) → y = ${poly([[m,1],[b,0]])}.`);}
 const mm=-1/m,bb=(y1*m+x1)/m;
 G({curves:[cv(x=>m*x+7,'given: y = '+poly([[m,1],[7,0]]),0),cv(x=>mm*x+bb,'new: y = '+fmtNum(mm)+'x + '+fmtNum(bb),1)],pts:[pt(x1,y1,`(${M(x1)}, ${M(y1)})`,{color:2,pos:'tr'})],equal:true,xr:[-12,12],yr:[-12,12],caption:'The two lines cross at a right angle (equal scales on both axes make this visible).'});
 return fill(`Find the line through (${M(x1)}, ${M(y1)}) perpendicular to y = ${poly([[m,1],[7,0]])}.`,['y = ',mm,'x + ',bb],`Perpendicular slope = −1/${P(m)} = ${fmtNum(mm)}. y − ${P(y1)} = ${fmtNum(mm)}(x − ${P(x1)}) → y = ${fmtNum(mm)}x + ${fmtNum(x1/m)} ${y1<0?'−':'+'} ${Math.abs(y1)} = ${fmtNum(mm)}x + ${fmtNum(bb)}.`);});

gen('lin','linapp',()=>{const m=nz(-5,5),b=rnd(-8,8);let x1=rnd(-4,4),x2=rnd(-4,4);if(x1===x2)x2=x1+2;const y1=m*x1+b,y2=m*x2+b;G({curves:[cv(x=>m*x+b,'f(x) = '+poly([[m,1],[b,0]]),0)],pts:[pt(x1,y1,`(${M(x1)}, ${M(y1)})`,{color:1,pos:'tr'}),pt(x2,y2,`(${M(x2)}, ${M(y2)})`,{color:1,pos:'br'})],caption:'Two points fix a line. Its slope and intercept are the f(x) you found.'});
 return fill(`f is linear with f(${M(x1)}) = ${M(y1)} and f(${M(x2)}) = ${M(y2)}. Find f(x).`,['f(x) = ',m,'x + ',b],`Slope = (${M(y2)} − ${P(y1)})/(${M(x2)} − ${P(x1)}) = ${M(y2-y1)}/${M(x2-x1)} = ${M(m)}. Then y − ${P(y1)} = ${M(m)}(x − ${P(x1)}) → f(x) = ${poly([[m,1],[b,0]])}.`);});

gen('lin','linapp',()=>{const total=pick([60,80,100,120,150]),a=pick([2,3,4,5]),b=pick([1,2,3,5]);const ys=total/b;G({curves:[cv(x=>ys-(a/b)*x,`${a}x + ${b}y = ${total}`,0,{x0:0,x1:total/a})],pts:[pt(0,ys,`(0, ${fmtNum(ys)})`,{color:1,pos:'tr'}),pt(total/a,0,`(${fmtNum(total/a)}, 0)`,{color:1,pos:'tl'})],xlab:'x (units of A)',ylab:'y (units of B)',caption:'Every point on the line uses all '+total+' hours. Points below the line leave hours unused; points above are impossible.'});
 return fill(`A firm has ${total} hours of labour. Product A takes ${a} h/unit and product B ${b} h/unit. x units of A and y units of B use all the hours. Write the equation, then solve it for y.`,['',a,'x + ',b,'y = ',total,'   →   y = ',ys,' + ',-a/b,'x'],`Hours used: ${a}x + ${b}y = ${total}. Solve for y: ${b}y = ${total} − ${a}x → y = ${fmtNum(ys)} − ${fmtNum(a/b)}x.`);});

gen('lin','linapp',()=>{const p1=rnd(5,15),dq=pick([10,20,50,100]),dp=pick([1,2,5]);const q1=rnd(2,8)*100;G({curves:[cv(x=>p1-(dp/dq)*(x-q1),'demand line',0)],pts:[pt(q1,p1,`(${q1}, $${p1})`,{color:1,pos:'tr'}),pt(q1-dq,p1+dp,`(${q1-dq}, $${p1+dp})`,{color:1,pos:'tr'})],xr:[q1-dq*3,q1+dq*2],yr:[p1-dp*2,p1+dp*3],xlab:'quantity q',ylab:'price p',caption:'Demand slopes down: a lower quantity goes with a higher price, so the slope is negative.'});
 return fill(`At a price of $${p1}, ${q1} units are demanded; at $${p1+dp}, ${q1-dq} are demanded. What is the slope of the demand line (p as a function of q)?`,['m = ',-dp/dq],`Points (q, p): (${q1}, ${p1}) and (${q1-dq}, ${p1+dp}). m = (${p1+dp} − ${p1})/(${q1-dq} − ${q1}) = ${dp}/${M(-dq)} = ${frac(-dp,dq)}. Negative, as demand should be. Price is on the vertical axis.`);});

gen('lin','systems',()=>{const x0=rnd(-5,5),y0=rnd(-5,5);let a=nz(-4,4),b=nz(-4,4),c=nz(-4,4),d=nz(-4,4);if(a*d-b*c===0)d+=1;if(a*d-b*c===0)d+=1;if(d===0)d=2;if(a*d-b*c===0)a+=1;const e1=a*x0+b*y0,e2=c*x0+d*y0;
 const eq=(p,q,r)=>`${poly([[p,1]])} ${q<0?'−':'+'} ${Math.abs(q)===1?'':Math.abs(q)}y = ${M(r)}`;
 G({curves:[cv(x=>(e1-a*x)/b,eq(a,b,e1).replace(/ \+ -/,' − '),0),cv(x=>(e2-c*x)/d,eq(c,d,e2),1)],pts:[pt(x0,y0,`(${M(x0)}, ${M(y0)})`,{color:2})],caption:'Each equation is a line. The solution of the system is the one point on both lines: where they cross.'});
 return fill(`Solve the system:<div class="big">${eq(a,b,e1)}<br>${eq(c,d,e2)}</div>`,['x = ',x0,'      y = ',y0],`Use elimination: multiply the first equation by ${P(c)} and the second by ${P(a)}, then subtract to remove x: (${M(b*c)} − ${P(a*d)})y = ${M(e1*c)} − ${P(e2*a)} → y = ${M(y0)}. Substitute back: x = ${M(x0)}.<br>Check eq.1: ${a}(${M(x0)}) + ${b}(${M(y0)}) = ${M(e1)} ✓`);});

gen('lin','systems',()=>{const a=nz(-4,4),b=nz(-4,4),c=rnd(-6,6);const k=pick([2,3,-2]);const kind=pick(['none','inf','one']);let A2=a*k,B2=b*k,C2=kind==='inf'?c*k:c*k+pick([1,2,5]);if(kind==='one'){B2=B2+1;}
 const eq=(p,q,r)=>`${poly([[p,1]])} ${q<0?'−':'+'} ${Math.abs(q)===1?'':Math.abs(q)}y = ${M(r)}`;const n={one:1,none:0,inf:Infinity}[kind];
 {const det=a*B2-A2*b;G({curves:[cv(x=>(c-a*x)/b,eq(a,b,c),0),cv(x=>(C2-A2*x)/B2,eq(A2,B2,C2),1,{dash:kind==='inf'})],pts:kind==='one'?[pt((c*B2-C2*b)/det,(a*C2-A2*c)/det,'one solution',{color:2})]:[],xr:[-8,8],yr:[-8,8],caption:kind==='one'?'The lines cross once: one solution.':kind==='none'?'The lines are parallel: they never meet, so there is no solution.':'The lines are the same line (one is drawn dashed on top): every point is a solution.'});}
 return fill(`How many solutions does this system have? (Type 0, 1 or ∞.)<div class="big">${eq(a,b,c)}<br>${eq(A2,B2,C2)}</div>`,['Number of solutions: ',{v:n,c:true}],kind==='inf'?`The second equation is the first × ${k}: same line, so every point on it is a solution (infinitely many).`:kind==='none'?`The left side of eq.2 is eq.1’s left side × ${k}, but the right side isn’t (${M(c*k)} ≠ ${M(C2)}). Same slope, different line → parallel → no solution.`:`The coefficients aren’t proportional, so the slopes differ and the lines cross exactly once.`);});

gen('lin','equil',()=>{const q0=rnd(2,12)*10,a=pick([1,2,3]),c=pick([1,2,4]);const s=pick([10,20,5]),b=rnd(1,6)*s/10;const p0=a*q0/10+b,d=p0+c*q0/10;
 const r=x=>Math.round(x*100)/100;
 G({curves:[cv(x=>(a/10)*x+b,'supply',0,{x0:0}),cv(x=>-(c/10)*x+d,'demand',1,{x0:0})],pts:[pt(q0,p0,`equilibrium (${q0}, $${r(p0)})`,{color:2,pos:'tr'})],xr:[0,q0*2],xlab:'quantity q',ylab:'price p ($)',caption:'Supply rises with price, demand falls. The market settles where they cross.'});
 return fill(`Supply: p = (${a}/10)q + ${r(b)}. Demand: p = −(${c}/10)q + ${r(d)}. Find the equilibrium quantity and price.`,['q = ',q0,'      p = $',r(p0)],`Set supply = demand: (${a}/10)q + ${r(b)} = −(${c}/10)q + ${r(d)} → (${a+c}/10)q = ${r(d-b)} → q = ${q0}. Then p = (${a}/10)(${q0}) + ${r(b)} = $${r(p0)}.`);});

gen('lin','equil',()=>{const items=[['A per-unit tax is put on suppliers. What happens to equilibrium?','Price rises, quantity falls','The supply curve shifts up by the tax, meeting the downward demand curve higher and further left (Example 1: q 100 → 85, p $5 → $6.05).'],['Where is the equilibrium point?','Where the supply and demand curves intersect','At equilibrium, quantity supplied equals quantity demanded at the same price.'],['At a price above equilibrium, there is…','A surplus (supply > demand)','Producers want to sell more than consumers want to buy.'],['At a price below equilibrium, there is…','A shortage (demand > supply)','Consumers want more than producers will supply.']];const [q,a,why]=pick(items);
 G({curves:[cv(x=>0.03*x+2,'supply',0,{x0:0}),cv(x=>-0.07*x+12,'demand',1,{x0:0}),cv(x=>0.03*x+3.5,'supply after a $1.50 tax',0,{x0:0,dash:true})],pts:[pt(100,5,'equilibrium (100, $5)',{color:2,pos:'bl'}),pt(85,6.05,'after tax (85, $6.05)',{color:1,pos:'tr'})],xr:[0,160],xlab:'quantity q',ylab:'price p ($)',caption:'Example from the slides. A tax shifts supply up (dashed), so the new meeting point is at a higher price and lower quantity.'});
 return{q,o:mcq(a,shuffle(['Price rises, quantity falls','Price falls, quantity rises','Where the supply and demand curves intersect','A surplus (supply > demand)','A shortage (demand > supply)','Where demand crosses the y-axis'])),e:why};});

gen('lin','breakeven',()=>{const v=rnd(2,15),p=v+pick([2,4,5,8,10]),m=p-v,q=rnd(2,20)*50,F=m*q;{const TR=x=>p*x,TC=x=>v*x+F;G({curves:[cv(TR,'revenue TR = '+p+'q',0),cv(TC,'cost TC = '+v+'q + '+F.toLocaleString('en-US'),1)],fills:[{f:TR,g:TC,x0:0,x1:q,color:1},{f:TR,g:TC,x0:q,x1:q*2,color:2}],pts:[pt(q,TR(q),`break-even (${q}, $${TR(q).toLocaleString('en-US')})`,{color:3,pos:'br'})],xr:[0,q*2],yr:[0,p*q*2.1],xlab:'quantity q',ylab:'dollars',caption:'Left of the crossing the cost line is higher (loss). Right of it revenue is higher (profit).'});}
 return fill(`A product sells for $${p}/unit, variable cost is $${v}/unit, fixed cost is $${F.toLocaleString('en-US')}. Find the break-even quantity.`,['q = ',q,' units'],`Break-even: TR = TC → ${p}q = ${v}q + ${F} → ${m}q = ${F} → q = ${q}. Each unit contributes $${m} toward fixed costs (the contribution margin).`);});

gen('lin','breakeven',()=>{const v=rnd(2,12),p=v+pick([3,4,5,6]),m=p-v,F=rnd(4,20)*500,q=rnd(2,30)*50;const pr=m*q-F;
 {const TR=x=>p*x,TC=x=>v*x+F,be=F/m,X=Math.max(q,be)*1.6;G({curves:[cv(TR,'revenue',0),cv(TC,'cost',1)],fills:[{f:TR,g:TC,x0:0,x1:be,color:1},{f:TR,g:TC,x0:be,x1:X,color:2}],pts:[pt(be,TR(be),`break-even ${fmtNum(be)}`,{color:3,pos:'br',open:true}),pt(q,TR(q),'',{color:0}),pt(q,TC(q),'',{color:1})],segs:[sg(q,TC(q),q,TR(q),{color:2,dash:false,label:(pr<0?'loss ':'profit ')+'$'+Math.abs(pr).toLocaleString('en-US')})],xr:[0,X],xlab:'quantity q',ylab:'dollars',caption:'At '+q+' units the vertical gap between the lines is the profit (or the loss when cost is above revenue).'});}
 return fill(`Price $${p}/unit, variable cost $${v}/unit, fixed cost $${F.toLocaleString('en-US')}. Find the profit at ${q} units. (Enter a loss as a negative number.)`,['Profit = $',pr],`Profit = TR − TC = ${p}(${q}) − (${v}(${q}) + ${F}) = ${p*q} − ${v*q+F} = ${M(pr)}. ${pr<0?'Negative means a loss.':pr===0?'Exactly break-even.':''}`);});

gen('lin','parab',()=>{const a=nz(-3,3),h=rnd(-5,5),k=rnd(-9,9);const b=-2*a*h,c=a*h*h+k;G(parG(a,b,c,{vertex:true,roots:false,cap:'The vertex is the turning point: the lowest point if the parabola opens up, the highest if it opens down.'}));
 return fill(`Find the vertex of y = ${poly([[a,2],[b,1],[c,0]])}.`,['vertex (',h,', ',k,')'],`x = −b/(2a) = ${M(-b)}/${M(2*a)} = ${M(h)}. y = ${co(a)}(${M(h)})² ${b<0?'−':'+'} ${Math.abs(b)}(${M(h)}) ${c<0?'−':'+'} ${Math.abs(c)} = ${M(k)}. Since a ${a>0?'> 0 it opens up: vertex is a minimum.':'< 0 it opens down: vertex is a maximum.'}`);});

gen('lin','parab',()=>{const a=nz(-3,3),r1=rnd(-6,5),r2=r1+rnd(1,6);const b=-a*(r1+r2),c=a*r1*r2;const t=pick(['int','dir','y']);
 G(parG(a,b,c,t==='int'?{}:t==='dir'?{vertex:true,roots:false,cap:a>0?'It opens up like a bowl, so the vertex is the lowest point.':'It opens down like a hill, so the vertex is the highest point.'}:{yint:true,roots:false,cap:'The y-intercept is where the curve crosses the y-axis (x = 0).'}));
 if(t==='int')return fill(`Find the x-intercepts of y = ${poly([[a,2],[b,1],[c,0]])}.`,['x-intercepts: ',{set:[r1,r2]}],`Set y = 0 and factor: ${co(a)}(x ${-r1<0?'−':'+'} ${Math.abs(r1)})(x ${-r2<0?'−':'+'} ${Math.abs(r2)}) = 0 → x = ${M(r1)} or x = ${M(r2)}.`.replace(/\(x [+−] 0\)/g,'x'),{any:true});
 if(t==='dir')return{q:`Does y = ${poly([[a,2],[b,1],[c,0]])} open up or down, and is its vertex a max or min?`,o:mcq(a>0?'Opens up; vertex is a minimum':'Opens down; vertex is a maximum',['Opens up; vertex is a maximum','Opens down; vertex is a minimum',a>0?'Opens down; vertex is a maximum':'Opens up; vertex is a minimum']),e:`Look at a, the x² coefficient: a = ${M(a)} ${a>0?'> 0 → opens up (∪), lowest point = minimum.':'< 0 → opens down (∩), highest point = maximum. In business this is how you find maximum revenue or profit.'}`};
 return fill(`Find the y-intercept of y = ${poly([[a,2],[b,1],[c,0]])}.`,['(0, ',c,')'],`Set x = 0: every x-term vanishes, leaving y = c = ${M(c)}.`);});

gen('lin','parab',()=>{const a=-pick([1,2,5]),h=pick([10,20,25,40,50]);const b=-2*a*h;G({curves:[cv(x=>a*x*x+b*x,'revenue r = '+poly([[a,2],[b,1]],'q'),0,{x0:0,x1:2*h})],pts:[pt(h,-a*h*h,`max revenue $${(-a*h*h).toLocaleString('en-US')} at q = ${h}`,{color:2,pos:'tr'})],segs:drop(h,-a*h*h),xr:[0,2*h*1.05],xlab:'quantity q',ylab:'revenue r ($)',caption:'Revenue rises, peaks at the vertex, then falls as the price needed to sell more is pushed down.'});
 return fill(`Revenue is r = ${poly([[a,2],[b,1]],'q')}. Which quantity q maximizes revenue, and what is the maximum revenue?`,['q = ',h,'      r = ',-a*h*h],`a = ${a} < 0, so the vertex is a maximum. q = −b/(2a) = ${M(-b)}/${M(2*a)} = ${h}. r = ${a}(${h})² + ${b}(${h}) = ${(a*h*h).toLocaleString('en-US')} + ${(b*h).toLocaleString('en-US')} = ${(-a*h*h).toLocaleString('en-US')}.`);});

gen('lin','elast',()=>{const B=pick([1,2,3,4,5]),p=pick([5,10,15,20,25]),q=pick([20,30,40,50,60,80,100,150]);const A=q+B*p;const eta=-B*p/q;const r=x=>(Math.round(x*100)/100).toFixed(2).replace('-','−');
 G({curves:[cv(x=>(A-x)/B,'demand curve',0,{x0:0,x1:A})],pts:[pt(q,p,`p = ${p}, q = ${q}`,{color:1,pos:'tr'}),pt(A/2,A/(2*B),'|η| = 1',{color:2,pos:'tr',open:true})],xr:[0,A],yr:[0,A/B*1.05],xlab:'quantity q',ylab:'price p',caption:'Higher up the demand line (high price, low quantity) demand is elastic, |η| > 1. Lower down it is inelastic. The open dot marks the midpoint where |η| = 1.'});
 return fill(`Demand is q = ${A} − ${B===1?'':B}p. Find the point elasticity of demand at p = ${p} (2 decimals).`,['η = ',{v:eta,d:r(eta),tol:0.006}],`At p = ${p}: q = ${A} − ${B}(${p}) = ${q}. dq/dp = −${B}. η = (p/q)(dq/dp) = (${p}/${q})(−${B}) = ${r(eta)}. |η| ${Math.abs(eta)>1?'> 1 → elastic: demand reacts strongly to price.':Math.abs(eta)<1?'< 1 → inelastic: demand reacts weakly to price.':'= 1 → unit elastic.'}`);});

gen('lin','elast',()=>{const items=[['Demand is elastic (|η| > 1). A firm raises its price. What happens to total revenue?','Revenue falls','Quantity drops by a bigger percentage than price rises, so p·q goes down.'],['Demand is inelastic (|η| < 1). A firm raises its price. What happens to total revenue?','Revenue rises','Quantity drops by a smaller percentage than price rises, so p·q goes up.'],['At which point is revenue maximized for a linear demand curve?','Where demand is unit elastic (|η| = 1)','Below that point a price rise helps revenue; above it, a price rise hurts revenue.'],['What does |η| > 1 mean?','Demand is elastic: quantity reacts more than proportionally to price','Elastic = sensitive. A 1% price change moves quantity by more than 1%.']];const [q,a,why]=pick(items);
 G(TUTG.elast[0]);
 return{q,o:mcq(a,shuffle(['Revenue falls','Revenue rises','Revenue stays the same','Where demand is unit elastic (|η| = 1)','Demand is elastic: quantity reacts more than proportionally to price','Demand is inelastic: quantity barely reacts to price'])),e:why};});


/* ===== Focus set: domain & range, transformations/reflections, inverse functions ===== */
const intv=(a,k)=>k==='ge'?`[${a}, ∞)`:k==='gt'?`(${a}, ∞)`:k==='le'?`(−∞, ${a}]`:k==='lt'?`(−∞, ${a})`:`(−∞, ${a}) ∪ (${a}, ∞)`;
gen('fun','domrange',()=>{const a=pick([1,2,3,4,-1,-2,-3]),b=rnd(-9,9),ge=a>0,bd=-b/a,P_=poly([[a,1],[b,0]]);
 G({curves:[cv(x=>Math.sqrt(a*x+b),`f(x) = √(${P_})`,0,ge?{x0:bd}:{x1:bd})],pts:[pt(bd,0,`edge: x = ${fmtNum(bd)}`,{color:1,pos:ge?'tr':'tl'})],xr:ge?[bd-4,bd+10]:[bd-10,bd+4],yr:[-1,5],caption:`The curve exists only on one side of x = ${fmtNum(bd)}: there the number under the root is ≥ 0.`});
 return fill(`Find the domain of f(x) = √(${P_})`,['x ',{sel:ge?'≥':'≤'},' ',bd],`A square root needs a radicand ≥ 0: ${P_} ≥ 0 → ${co(a)}x ≥ ${M(-b)} → x ${ge?'≥':'≤'} ${fmtNum(bd)}.${ge?'':' Dividing by the negative number '+M(a)+' <b>flips</b> the inequality sign.'}`);});

gen('fun','domrange',()=>{const p=nz(-4,4),q=p+rnd(1,5);
 G({curves:[cv(x=>Math.sqrt(x-p)/(x-q),`f(x) = √(x ${p<0?'+':'−'} ${Math.abs(p)}) / (x ${q<0?'+':'−'} ${Math.abs(q)})`,0,{x0:p})],vlines:[{x:q,label:`x = ${M(q)}`}],pts:[pt(p,0,`start x = ${M(p)}`,{color:1,pos:'bl'})],xr:[p-2,q+8],yr:[-4,4],caption:'Two restrictions at once: the graph starts at the root’s edge, and has a break at the zero of the denominator.'});
 return fill(`Find the domain of f(x) = √(x ${p<0?'+':'−'} ${Math.abs(p)}) / (x ${q<0?'+':'−'} ${Math.abs(q)})`,['x ',{sel:'≥'},' ',p,'   and   x ',{sel:'≠'},' ',q],`Root: x ${p<0?'+':'−'} ${Math.abs(p)} ≥ 0 → x ≥ ${M(p)}. Denominator: x ${q<0?'+':'−'} ${Math.abs(q)} ≠ 0 → x ≠ ${M(q)}, and ${M(q)} is inside x ≥ ${M(p)}, so it must be removed. Combine both rules.`);});

gen("fun","domrange",()=>{const p=nz(-5,5);
 G({curves:[cv(x=>1/Math.sqrt(x-p),`f(x) = 1/√(x ${p<0?'+':'−'} ${Math.abs(p)})`,0,{x0:p+0.02})],vlines:[{x:p,label:`x = ${M(p)}`}],xr:[p-3,p+9],yr:[0,4],caption:'The curve gets arbitrarily close to the dashed line but never touches it: x = '+M(p)+' itself is excluded.'});
 return fill(`Find the domain of f(x) = 1/√(x ${p<0?'+':'−'} ${Math.abs(p)})`,['x ',{sel:'>'},' ',p],`The root needs x ${p<0?'+':'−'} ${Math.abs(p)} ≥ 0, but it is also in a denominator, so it can't be 0. That makes the inequality strict: x > ${M(p)}.`);});

gen('fun','domrange',()=>{const r1=rnd(-5,3),r2=r1+rnd(1,5),b=-(r1+r2),c=r1*r2;
 G({curves:[cv(x=>1/(x*x+b*x+c),`f(x) = 1/(${poly([[1,2],[b,1],[c,0]])})`,0)],vlines:[{x:r1,label:`x = ${M(r1)}`},{x:r2,label:`x = ${M(r2)}`}],xr:[r1-4,r2+4],yr:[-3,3],caption:'One break at each value that makes the denominator zero.'});
 return fill(`Find the domain of f(x) = 1/(${poly([[1,2],[b,1],[c,0]])})..`,['Excluded x-values: ',{set:[r1,r2]}],`Solve the denominator = 0: ${poly([[1,2],[b,1],[c,0]])} = (x ${-r1<0?'−':'+'} ${Math.abs(r1)})(x ${-r2<0?'−':'+'} ${Math.abs(r2)}) = 0 → x = ${M(r1)} or x = ${M(r2)}. Exclude both.`.replace(/\(x [+−] 0\)/g,'x'),{any:true});});

gen('fun','domrange',()=>{const a=pick([1,1,2,3,-1,-1,-2]),h=rnd(-5,5),k=rnd(-8,8),b=-2*a*h,c=a*h*h+k,up=a>0,vf=Math.random()<0.5;
 const eqs=vf?`${co(a)}(x ${h<0?'+':'−'} ${Math.abs(h)})² ${k<0?'−':'+'} ${Math.abs(k)}`:poly([[a,2],[b,1],[c,0]]);
 G(Object.assign(parG(a,b,c,{vertex:true,roots:false,cap:`The vertex (${M(h)}, ${M(k)}) is the ${up?'lowest':'highest'} point, so every output is ${up?'≥':'≤'} ${M(k)}.`}),{hlines:[{y:k,label:`y = ${M(k)}`}]}));
 return fill(`Find the range of f(x) = ${eqs}`,['y ',{sel:up?'≥':'≤'},' ',k],vf?`In vertex form the vertex is (${M(h)}, ${M(k)}). Since a = ${a} ${up?'> 0 the parabola opens up, so the vertex is the lowest point: range y ≥':'< 0 the parabola opens down, so the vertex is the highest point: range y ≤'} ${M(k)}.`:`Vertex: x = −b/(2a) = ${M(-b)}/${M(2*a)} = ${M(h)}, y = ${M(k)}. Since a = ${a} ${up?'> 0 the parabola opens up (vertex = minimum): range y ≥':'< 0 it opens down (vertex = maximum): range y ≤'} ${M(k)}.`);});

gen('fun','domrange',()=>{const t=pick(['sqrt','nsqrt','abs','nabs','rat']),p=rnd(-4,4),k=rnd(-6,6),X=p<0?'+':'−',pa=Math.abs(p);const ks=k===0?'':` ${k<0?'−':'+'} ${Math.abs(k)}`;
 const defs={sqrt:[`√(x ${X} ${pa})${ks}`,x=>Math.sqrt(x-p)+k,'y ≥ ',`The root is never negative, so √(…) ≥ 0, and adding ${M(k)} shifts the lowest output to ${M(k)}.`],
  nsqrt:[`−√(x ${X} ${pa})${ks}`,x=>-Math.sqrt(x-p)+k,'y ≤ ','The minus sign flips the root upside down: −√(…) ≤ 0, so the highest output is '+M(k)+'.'],
  abs:[`|x ${X} ${pa}|${ks}`,x=>Math.abs(x-p)+k,'y ≥ ',`|…| ≥ 0, so the smallest output is ${M(k)} (at the corner).`],
  nabs:[`−|x ${X} ${pa}|${ks}`,x=>-Math.abs(x-p)+k,'y ≤ ',`−|…| ≤ 0, so the largest output is ${M(k)} (at the corner).`]};
 if(t==='rat'){const a=pick([1,2,-1,-2]);
  G({curves:[cv(x=>a/(x-p)+k,`f(x) = ${a}/(x ${X} ${pa})${ks}`,0)],vlines:[{x:p,label:`x = ${M(p)}`}],hlines:[{y:k,label:`y = ${M(k)}`}],xr:[p-7,p+7],yr:[k-7,k+7],caption:`The curve gets close to the dashed horizontal line y = ${M(k)} but never reaches it: that output is missing from the range.`});
  return fill(`Find the range of f(x) = ${a}/(x ${X} ${pa})${ks}`,['Excluded y-value: ',{set:[k]}],`${a}/(x ${X} ${pa}) can be any nonzero number but never exactly 0, so adding ${M(k)} gives every output except ${M(k)}.`);}
 const d=defs[t];const up=d[2]==='y ≥ ';
 G({curves:[cv(d[1],'f(x) = '+d[0],0,/sqrt/.test(t)?{x0:p}:{})],pts:[pt(p,k,`(${M(p)}, ${M(k)})`,{color:1,pos:up?'br':'tr'})],hlines:[{y:k,label:`y = ${M(k)}`}],xr:[p-5,p+9],yr:[up?k-3:k-8,up?k+8:k+3],caption:`Read the range off the y-axis: the graph ${up?'never goes below':'never goes above'} y = ${M(k)}.`});
 return fill(`Find the range of f(x) = ${d[0]}`,['y ',{sel:up?'≥':'≤'},' ',k],d[3]);});

gen('fun','domrange',()=>{const c=rnd(1,7);
 const items=[
  [`Which function has domain x ≥ ${c}?`,`f(x) = √(x − ${c})`,[`f(x) = √(${c} − x)`,`f(x) = 1/(x − ${c})`,`f(x) = x² − ${c}`],x=>Math.sqrt(x-c),'A root needs radicand ≥ 0: x − '+c+' ≥ 0 gives x ≥ '+c+'. √('+c+' − x) would give x ≤ '+c+'.'],
  [`Which function has domain “all real numbers except x = ${c}”?`,`f(x) = 1/(x − ${c})`,[`f(x) = √(x − ${c})`,`f(x) = (x − ${c})²`,`f(x) = |x − ${c}|`],x=>1/(x-c),'Only a denominator can forbid a single value: x − '+c+' = 0 at x = '+c+'. The others accept every real x.'],
  [`Which function has range y ≥ ${c}?`,`f(x) = x² + ${c}`,[`f(x) = −x² + ${c}`,`f(x) = x³ + ${c}`,`f(x) = x + ${c}`],x=>x*x+c,'x² ≥ 0, so x² + '+c+' ≥ '+c+'. −x² + '+c+' has range y ≤ '+c+'; odd powers and lines reach every real value.'],
  [`Which function has range y ≤ ${c}?`,`f(x) = ${c} − x²`,[`f(x) = x² + ${c}`,`f(x) = x³ + ${c}`,`f(x) = |x| + ${c}`],x=>c-x*x,'x² ≥ 0, so '+c+' − x² ≤ '+c+': an upside-down parabola with its peak at '+c+'.'],
  [`The range of f(x) = |x − 3| + ${c} is…`,`y ≥ ${c}`,[`y ≥ 3`,`y ≤ ${c}`,`All real numbers`],x=>Math.abs(x-3)+c,'|…| ≥ 0, so the smallest output is '+c+'. The horizontal shift (3) never affects the range.']];
 const [q,ans,wr,F,why]=pick(items);G({curves:[cv(F,ans.startsWith('f(x)')?ans:'f(x) = |x − 3| + '+c,0,{x0:/√/.test(ans)?c:undefined})],xr:[-6,14],yr:[-4,12],caption:'Check with the picture: which x-values does the graph cover (domain) and which heights (range)?'});
 return{q,o:mcq(ans,wr),e:why};});

gen('fun','domrange',()=>{const a=rnd(-6,6),k=pick(['ge','gt','le','lt','ne']);const txt={ge:`x ≥ ${M(a)}`,gt:`x > ${M(a)}`,le:`x ≤ ${M(a)}`,lt:`x < ${M(a)}`,ne:`x ≠ ${M(a)}`}[k];
 const A=M(a),ans=intv(A,k),wr=['ge','gt','le','lt','ne'].filter(z=>z!==k).map(z=>intv(A,z));
 return{q:`Write ${txt} in interval notation.`,o:mcq(ans,wr),e:`Square bracket [ ] means the end point <b>is included</b> (≥ or ≤). Round bracket ( ) means it is <b>not</b> (> or <), and infinity always gets a round bracket. “≠” removes one point, so it splits the line into two pieces joined by ∪.`};});

/* ---- Transformations of graphs ---- */
gen('fun','trans',()=>{const F=pick([[x=>x*x,'x²'],[x=>x**3,'x³']]),p=pick([-3,-2,-1,1,2,3]),q=F[0](p),h=nz(-4,4),k=nz(-4,4);
 const S=v=>v<0?'−':'+';
 const T=pick([
  ['−f(x)',(x,y)=>[x,-y],x=>-F[0](x),'The minus is <b>outside</b>: it changes the output, so y → −y (reflection in the x-axis). x stays.'],
  ['f(−x)',(x,y)=>[-x,y],x=>F[0](-x),'The minus is <b>inside</b>: it changes the input, so x → −x (reflection in the y-axis). y stays.'],
  [`f(x ${S(-h)} ${Math.abs(h)})`,(x,y)=>[x+h,y],x=>F[0](x-h),`Inside shifts go the “wrong” way: x ${S(-h)} ${Math.abs(h)} moves the graph ${h>0?'right':'left'} ${Math.abs(h)}, so x → x ${S(h)} ${Math.abs(h)}.`],
  [`f(x) ${S(k)} ${Math.abs(k)}`,(x,y)=>[x,y+k],x=>F[0](x)+k,`Outside shifts do what they say: ${S(k)}${Math.abs(k)} moves the graph ${k>0?'up':'down'}, so y → y ${S(k)} ${Math.abs(k)}.`],
  ['2f(x)',(x,y)=>[x,2*y],x=>2*F[0](x),'Outside multiplier: every output doubles (vertical stretch). x stays.'],
  ['f(2x)',(x,y)=>[x/2,y],x=>F[0](2*x),'Inside multiplier works backwards: f(2x) reaches the same height at half the x (horizontal compression), so x → x/2.'],
  ['f(x/2)',(x,y)=>[2*x,y],x=>F[0](x/2),'Inside multiplier works backwards: f(x/2) needs twice the x for the same height (horizontal stretch), so x → 2x.'],
  [`−f(x ${S(-h)} ${Math.abs(h)})`,(x,y)=>[x+h,-y],x=>-F[0](x-h),`Two steps: shift ${h>0?'right':'left'} ${Math.abs(h)} (x → x ${S(h)} ${Math.abs(h)}) and flip over the x-axis (y → −y).`],
  [`f(−x) ${S(k)} ${Math.abs(k)}`,(x,y)=>[-x,y+k],x=>F[0](-x)+k,`Two steps: flip left–right (x → −x), then move ${k>0?'up':'down'} ${Math.abs(k)} (y → y ${S(k)} ${Math.abs(k)}).`]]);
 const [nx,ny]=T[1](p,q);
 G({curves:[cv(F[0],'y = f(x) = '+F[1],3,{dash:true}),cv(T[2],'y = '+T[0],1)],pts:[pt(p,q,`(${M(p)}, ${M(q)})`,{color:3,pos:p>0?'br':'bl'}),pt(nx,ny,`(${fmtNum(nx)}, ${fmtNum(ny)})`,{color:1,pos:nx>0?'tr':'tl'})],xr:[-9,9],yr:[-13,18],caption:'The dashed curve is f. Follow the marked point: it moves from its old position to the new one under the transformation.'});
 return fill(`f(x) = ${F[1].replace('²','<sup>2</sup>').replace('³','<sup>3</sup>')}, and the point (${M(p)}, ${M(q)}) is on the graph of y = f(x). Where does that point end up on the graph of y = ${T[0]}?`,['(',nx,', ',ny,')'],T[3]+` Start (${M(p)}, ${M(q)}) → (${fmtNum(nx)}, ${fmtNum(ny)}).`);});

gen('fun','trans',()=>{const a=nz(-3,3),b=nz(-5,5),c=rnd(-6,6),v=Math.random()<0.5;
 const A=v?-a:a,B=v?-b:b,C=v?-c:c;const lab=v?'−f(x)':'f(−x)';const f=poly([[a,2],[b,1],[c,0]]);
 G({curves:[cv(qf(a,b,c),'f(x) = '+f,3,{dash:true}),cv(qf(A,B,C),lab+' = '+poly([[A,2],[B,1],[C,0]]),1)],xr:[-7,7],yr:[-25,25],caption:v?'Flipped upside down over the x-axis: every height changes sign.':'Flipped left to right over the y-axis: the picture is mirrored sideways.'});
 return fill(`f(x) = ${f}. Find ${lab} and write it as ax² + bx + c.`,[lab+' = ',A,'x² + ',B,'x + ',C],v?`−f(x) multiplies the <b>whole</b> function by −1: change the sign of every term. −(${f}) = ${poly([[A,2],[B,1],[C,0]])}.`:`f(−x): replace each x by (−x). Even powers lose the sign, odd powers keep it: ${a}(−x)² = ${M(a)}x² (unchanged), ${M(b)}(−x) = ${M(-b)}x (flips), constant unchanged. Result: ${poly([[A,2],[B,1],[C,0]])}.`);});

gen('fun','trans',()=>{const h=nz(-6,6),k=nz(-6,6),s=pick(['a','b']);
 const eq=`y = f(x ${h<0?'+':'−'} ${Math.abs(h)}) ${k<0?'−':'+'} ${Math.abs(k)}`;
 G({curves:[cv(x=>x*x,'y = f(x) = x² (example)',3,{dash:true}),cv(x=>(x-h)**2+k,eq,1)],pts:[pt(0,0,'',{color:3,open:true}),pt(h,k,`(${M(h)}, ${M(k)})`,{color:1,pos:h>=0?'br':'bl'})],xr:[Math.min(-5,h-5),Math.max(5,h+5)],yr:[Math.min(-4,k-3),Math.max(10,k+9)],caption:'Shown with f(x) = x² as an example: the bracket value moves the graph sideways in the opposite direction to its sign.'});
 return fill(`How is the graph of ${eq} obtained from y = f(x)? (Right and up are positive; use a negative number for left or down.)`,['right ',h,'      up ',k],`Inside the bracket, x ${h<0?'+':'−'} ${Math.abs(h)} moves the graph ${h>0?'right':'left'} ${Math.abs(h)} (opposite to the sign you see: “x + 3” means <b>left</b> 3). Outside, ${k<0?'−':'+'} ${Math.abs(k)} moves it ${k>0?'up':'down'} ${Math.abs(k)}.`);});

gen('fun','trans',()=>{const F=x=>(x-1)**2+1;
 const items=[
  ['Which equation reflects y = f(x) in the y-axis (left ↔ right)?','y = f(−x)','The minus sign is inside, so it changes x and mirrors the graph sideways.',x=>F(-x),'y = f(−x)'],
  ['Which equation reflects y = f(x) in the x-axis (up ↔ down)?','y = −f(x)','The minus sign is outside, so it changes the outputs and flips the graph upside down.',x=>-F(x),'y = −f(x)'],
  ['Which equation reflects y = f(x) in the origin (both flips at once)?','y = −f(−x)','Flip left–right and flip up–down: that is a half-turn about the origin.',x=>-F(-x),'y = −f(−x)'],
  ['y = f(2x) is…','a horizontal compression by a factor of 2','Inside multipliers act on x and work “backwards”: you only need half as much x to reach each height, so the graph squeezes toward the y-axis.',x=>F(2*x),'y = f(2x)'],
  ['y = f(x/2) is…','a horizontal stretch by a factor of 2','Inside multipliers act on x and work “backwards”: you need twice as much x to reach each height, so the graph spreads out.',x=>F(x/2),'y = f(x/2)'],
  ['y = f(x + 3) is…','a shift 3 units to the left','Inside the bracket the shift goes the “wrong” way: x + 3 = 0 at x = −3, so the graph moves left.',x=>F(x+3),'y = f(x + 3)'],
  ['y = f(x) − 3 is…','a shift 3 units down','Outside the bracket the sign means what it says: subtract 3 from every output.',x=>F(x)-3,'y = f(x) − 3'],
  ['y = 3f(x) is…','a vertical stretch by a factor of 3','Outside multipliers act on y: every height is multiplied by 3.',x=>3*F(x),'y = 3f(x)']];
 const [q,ans,why,T,lab]=pick(items);const pool=['y = f(−x)','y = −f(x)','y = −f(−x)','y = f(x) + 3'];
 const wr=q.startsWith('Which')?pool.filter(z=>z!==ans):shuffle(['a shift 3 units to the left','a shift 3 units to the right','a shift 3 units down','a shift 3 units up','a horizontal compression by a factor of 2','a horizontal stretch by a factor of 2','a vertical stretch by a factor of 3','a vertical compression by a factor of 3','a reflection in the y-axis','a reflection in the x-axis']).filter(z=>z!==ans);
 G({curves:[cv(F,'y = f(x) = (x − 1)² + 1',3,{dash:true}),cv(T,lab,1)],xr:[-7,7],yr:[-12,16],caption:'Dashed: an example f. Solid: the transformed graph.'});
 return{q,o:mcq(ans,wr),e:why};});

/* ---- Inverse functions ---- */
gen('fun','inverse',()=>{const n=rnd(-3,3),k=nz(-8,8),m=n**3+k;
 G({curves:[cv(x=>x**3+k,`f(x) = x³ ${k<0?'−':'+'} ${Math.abs(k)}`,0),cv(x=>Math.cbrt(x-k),'f⁻¹(x)',1),cv(x=>x,'y = x',3,{dash:true})],pts:[pt(n,m,`f(${M(n)}) = ${M(m)}`,{color:0,pos:'tl'}),pt(m,n,`f⁻¹(${M(m)}) = ${M(n)}`,{color:1,pos:'br'})],equal:true,xr:[-12,12],yr:[-12,12],caption:'The point (n, m) on f swaps to (m, n) on f⁻¹: mirror images in y = x.'});
 return fill(`f(x) = x<sup>3</sup> ${k<0?'−':'+'} ${Math.abs(k)}. Find f⁻¹(${M(m)}).`,[`f⁻¹(${M(m)}) = `,n],`f⁻¹(${M(m)}) is the x that f sends to ${M(m)}: x³ ${k<0?'−':'+'} ${Math.abs(k)} = ${M(m)} → x³ = ${M(m-k)} → x = ${M(n)}.`);});

gen('fun','inverse',()=>{const a=nz(-4,4),k=nz(-5,5);
 G({curves:[cv(x=>a/x+k,`f(x) = ${M(a)}/x ${k<0?'−':'+'} ${Math.abs(k)}`,0),cv(x=>a/(x-k),'f⁻¹(x)',1),cv(x=>x,'y = x',3,{dash:true})],equal:true,xr:[-9,9],yr:[-9,9],caption:'f and f⁻¹ are mirror images in the dashed line y = x.'});
 return fill(`Find the inverse of f(x) = ${M(a)}/x ${k<0?'−':'+'} ${Math.abs(k)}. Write it as f⁻¹(x) = ${M(a)}/(x + c) and give c.`,['f⁻¹(x) = '+M(a)+' / (x + ',-k,')'],`Write y = ${M(a)}/x ${k<0?'−':'+'} ${Math.abs(k)} and swap: x = ${a}/y ${k<0?'−':'+'} ${Math.abs(k)}. Move the constant: x ${k<0?'+':'−'} ${Math.abs(k)} = ${a}/y. Then y = ${a}/(x ${k<0?'+':'−'} ${Math.abs(k)}). So c = ${M(-k)}.`);});

gen('fun','inverse',()=>{const p=nz(-5,5);
 G({curves:[cv(x=>Math.sqrt(x-p),`f(x) = √(x ${p<0?'+':'−'} ${Math.abs(p)})`,0,{x0:p}),cv(x=>x*x+p,'f⁻¹(x) = x² + '+M(p),1,{x0:0}),cv(x=>x,'y = x',3,{dash:true})],equal:true,xr:[Math.min(-3,p-1),Math.max(8,p+4)],yr:[Math.min(-3,p-1),Math.max(8,p+4)],caption:'The inverse of the root is a parabola, but only its right half (x ≥ 0): the range of f becomes the domain of f⁻¹.'});
 return fill(`f(x) = √(x ${p<0?'+':'−'} ${Math.abs(p)}). Find f⁻¹(x) = x² + c and its domain x ≥ d.`,['f⁻¹(x) = x² + ',p,'      domain x ',{sel:'≥'},' ',0],`y = √(x ${p<0?'+':'−'} ${Math.abs(p)}); swap: x = √(y ${p<0?'+':'−'} ${Math.abs(p)}); square: x² = y ${p<0?'+':'−'} ${Math.abs(p)} → y = x² ${p<0?'−':'+'} ${Math.abs(p)}. The inputs of f⁻¹ are the outputs of f, and √ is never negative, so x ≥ 0.`);});

gen('fun','inverse',()=>{let a=nz(-5,5),b=nz(-5,5);if(a===b)b+=1||2;if(b===0)b=2;
 G({curves:[cv(x=>Math.sqrt(x-a)+b,`f(x) = √(x ${a<0?'+':'−'} ${Math.abs(a)}) ${b<0?'−':'+'} ${Math.abs(b)}`,0,{x0:a}),cv(x=>(x-b)**2+a,'f⁻¹(x)',1,{x0:b}),cv(x=>x,'y = x',3,{dash:true})],pts:[pt(a,b,`start (${M(a)}, ${M(b)})`,{color:0,pos:'tl'}),pt(b,a,`start (${M(b)}, ${M(a)})`,{color:1,pos:'br'})],equal:true,xr:[Math.min(a,b)-3,Math.max(a,b)+9],yr:[Math.min(a,b)-3,Math.max(a,b)+9],caption:'The start point (a, b) of f becomes (b, a) for f⁻¹: domain and range swap.'});
 return fill(`f has domain x ≥ ${M(a)} and range y ≥ ${M(b)}. Give the domain and range of f⁻¹.`,['domain x ',{sel:'≥'},' ',b,'      range y ',{sel:'≥'},' ',a],`Inverses swap inputs and outputs, so they swap domain and range: domain of f⁻¹ = range of f (x ≥ ${M(b)}), range of f⁻¹ = domain of f (y ≥ ${M(a)}).`);});

gen('fun','inverse',()=>{const items=[
  ['f(x) = x²  (all real x)','No: some horizontal lines hit the graph twice, so it fails the horizontal line test','For example f(2) = f(−2) = 4, so the outputs can’t be traced back to one input.',x=>x*x,4],
  ['f(x) = x³','Yes: every horizontal line meets the graph exactly once','x³ is increasing everywhere, so each output comes from exactly one input.',x=>x**3,4],
  ['f(x) = |x|','No: some horizontal lines hit the graph twice, so it fails the horizontal line test','|2| = |−2| = 2, so two inputs share one output.',Math.abs,2],
  ['f(x) = 3x − 5','Yes: every horizontal line meets the graph exactly once','A non-horizontal line is one-to-one, so it always has an inverse.',x=>3*x-5,4],
  ['f(x) = x² restricted to x ≥ 0','Yes: restricting the domain removes the repeated outputs','On x ≥ 0 only the right half of the parabola remains, and each height appears once. Its inverse is √x.',x=>x>=0?x*x:NaN,4]];
 const [f,ans,why,F,hh]=pick(items);const wr=['Yes: every horizontal line meets the graph exactly once','No: some horizontal lines hit the graph twice, so it fails the horizontal line test','Yes: restricting the domain removes the repeated outputs','No: because the function has a domain restriction'].filter(z=>z!==ans);
 G({curves:[cv(F,f.replace(/ \(.*| restricted.*/,''),0,/x ≥ 0/.test(f)?{x0:0}:{})],hlines:[{y:hh,label:`y = ${hh}`}],xr:[-4,5],yr:[-6,10],caption:'Horizontal line test: if any horizontal line crosses the graph more than once, the function has no inverse (as it stands).'});
 return{q:`Does ${f} have an inverse function?`,o:mcq(ans,wr),e:why};});

/* ---- Vocabulary questions built from the glossary (multiple choice) ---- */
['alg','fun','lin'].forEach(t=>gen(t,'vocab',()=>{const pool=GLOSSARY.filter(g=>g[0]===t);const it=pick(pool);const others=shuffle(pool.filter(g=>g!==it)).map(g=>g[1]);
 return{q:`Which term matches this definition?<div class="def">${it[2]}</div>`,o:mcq(it[1],others),e:`<b>${it[1]}</b>: ${it[2]}${it[3]?'<br>Example: '+it[3]:''}`};}));
