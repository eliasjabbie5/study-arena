/* ===== Tutorials ===== */
const TUTS=[
{t:'alg',g:'props',title:'Properties of real numbers',html:`
<p>These rules say what you may do to an expression without changing its value. Exam questions often show an equation and ask which property it uses.</p>
<table class="rt"><tr><th>Property</th><th>Addition</th><th>Multiplication</th></tr>
<tr><td>Commutative (order)</td><td>a + b = b + a</td><td>ab = ba</td></tr>
<tr><td>Associative (grouping)</td><td>(a + b) + c = a + (b + c)</td><td>(ab)c = a(bc)</td></tr>
<tr><td>Identity</td><td>a + 0 = a</td><td>a · 1 = a</td></tr>
<tr><td>Inverse</td><td>a + (−a) = 0</td><td>a · (1/a) = 1, a ≠ 0</td></tr></table>
<p><b>Distributive:</b> a(b + c) = ab + ac. <b>Transitive:</b> if a = b and b = c then a = c. <b>Closure:</b> sums and products of reals are real.</p>
<div class="tip"><b>Memory trick:</b> commute = travel = things <i>move</i> (order). Associate = who you <i>group</i> with (brackets).</div>`},
{t:'alg',g:'exp',title:'Exponents and radicals',html:`
<p>In x<sup>n</sup>, x is the <b>base</b> and n the <b>exponent</b>.</p>
<ol class="steps"><li>x<sup>m</sup> · x<sup>n</sup> = x<sup>m+n</sup> (multiply → add)</li><li>x<sup>m</sup> / x<sup>n</sup> = x<sup>m−n</sup> (divide → subtract)</li><li>(x<sup>m</sup>)<sup>n</sup> = x<sup>mn</sup> (power of power → multiply)</li><li>x<sup>0</sup> = 1, x<sup>−n</sup> = 1/x<sup>n</sup></li><li>x<sup>1/n</sup> = ⁿ√x and x<sup>m/n</sup> = (ⁿ√x)<sup>m</sup></li></ol>
<p>In ⁿ√x, n is the <b>index</b> and x the <b>radicand</b>.</p>
<div class="worked"><div class="wl">Worked example</div>Simplify √72.<br>72 = 36 · 2 (36 is the biggest perfect square factor).<br>√72 = √36 · √2 = <b>6√2</b>.</div>
<div class="worked"><div class="wl">Worked example</div>Eliminate negative exponents in x<sup>−2</sup>y<sup>3</sup>.<br>x<sup>−2</sup> = 1/x<sup>2</sup>, so the answer is <b>y<sup>3</sup>/x<sup>2</sup></b>.</div>
<div class="tip"><b>Common mistake:</b> x<sup>−2</sup> is not −x<sup>2</sup>. A negative exponent flips position in the fraction; it doesn't change the sign.</div>`},
{t:'alg',g:'prod',title:'Special products and factoring',html:`
<p>Learn these by heart. Expanding goes left → right; factoring goes right → left.</p>
<ol class="steps"><li>(x + a)(x + b) = x² + (a + b)x + ab</li><li>(x + a)² = x² + 2ax + a²</li><li>(x − a)² = x² − 2ax + a²</li><li>(x + a)(x − a) = x² − a² (difference of squares)</li><li>(x + a)³ = x³ + 3ax² + 3a²x + a³</li></ol>
<p><b>Factoring steps:</b> (1) take out any common factor, (2) look for a difference of squares, (3) for x² + bx + c find two numbers that multiply to c and add to b.</p>
<div class="worked"><div class="wl">Worked example</div>Factor x² − 7x + 12.<br>Need product 12, sum −7 → −3 and −4.<br>Answer: <b>(x − 3)(x − 4)</b>. Check by expanding: x² − 4x − 3x + 12 ✓</div>
<div class="tip"><b>Common mistake:</b> (x + 3)² ≠ x² + 9. You lose the middle term 6x.</div>`},
{t:'alg',g:'frac',title:'Fractions and rationalizing',html:`
<p><b>Simplify</b> by dividing top and bottom by the same nonzero factor. <b>Multiply:</b> (a/b)(c/d) = ac/bd. <b>Divide:</b> flip the second and multiply. <b>Add/subtract:</b> get a common denominator first.</p>
<p><b>Rationalizing the denominator</b> removes radicals from the bottom:</p>
<ol class="steps"><li>Single root: multiply top and bottom by that root. 6/√3 = 6√3/3 = 2√3.</li><li>Sum/difference with roots: multiply by the <b>conjugate</b> to make a difference of squares. 1/(√5 − √2) × (√5 + √2)/(√5 + √2) = (√5 + √2)/3.</li></ol>
<div class="worked"><div class="wl">Worked example</div>2/3 + 1/4 = 8/12 + 3/12 = <b>11/12</b>.</div>
<div class="tip"><b>Common mistake:</b> 2/3 + 1/4 ≠ 3/7. Never add denominators.</div>`},
{t:'alg',g:'lineq',title:'Linear, literal and fractional equations',html:`
<p>A <b>linear equation</b> can be written ax + b = 0 with a ≠ 0. You solve it by building <b>equivalent equations</b>:</p>
<ol class="steps"><li>Add or subtract the same thing on both sides.</li><li>Multiply or divide both sides by the same <b>nonzero constant</b>.</li><li>Replace a side by an equal expression (simplify).</li></ol>
<p>Multiplying or dividing by an expression with the variable, or raising both sides to a power, may <b>not</b> give an equivalent equation, so always check answers.</p>
<div class="worked"><div class="wl">Worked example</div>Solve 5x − 6 = 3x.<br>Subtract 3x: 2x − 6 = 0. Add 6: 2x = 6. Divide by 2: <b>x = 3</b>.</div>
<div class="worked"><div class="wl">Literal equation</div>Solve I = Prt for r: divide both sides by Pt → <b>r = I/(Pt)</b>.</div>
<div class="worked"><div class="wl">Fractional equation</div>Solve 6/(x − 1) = 3: multiply by (x − 1): 6 = 3x − 3 → x = 3. Check: 3 − 1 ≠ 0 ✓</div>
<div class="worked"><div class="wl">Radical equation</div>Solve √(x + 3) = 4: square both sides: x + 3 = 16 → x = 13. Check: √16 = 4 ✓</div>`},
{t:'alg',g:'quad',title:'Quadratic equations',html:`
<p>A quadratic equation is ax² + bx + c = 0 with a ≠ 0. Three ways to solve:</p>
<ol class="steps"><li><b>Factoring</b> + zero-product rule: x² − x − 12 = 0 → (x − 4)(x + 3) = 0 → x = 4 or x = −3.</li><li><b>Quadratic formula:</b> x = (−b ± √(b² − 4ac)) / 2a. Always works.</li><li><b>Quadratic form:</b> substitute to make it quadratic, e.g. w = 1/x³ in 1/x⁶ − 9/x³ + 8 = 0.</li></ol>
<p>The <b>discriminant</b> b² − 4ac tells you the number of real roots: positive → 2, zero → 1, negative → 0.</p>
<div class="worked"><div class="wl">Slides, Example 7</div>9x² + 6√2x + 2 = 0: b² − 4ac = 72 − 72 = 0, so one root x = −6√2/18 = <b>−√2/3</b>.</div>
<div class="tip"><b>Common mistake:</b> never divide both sides by x. In x² = 5x you'd lose the root x = 0. Move everything to one side and factor: x(x − 5) = 0.</div>`},
{t:'fun',g:'func',title:'Functions, domain and evaluating',html:`
<p>A <b>function</b> gives each input exactly one output. The inputs form the <b>domain</b>, the outputs the <b>range</b>.</p>
<p><b>Finding the domain:</b> start with all real numbers and remove values that cause trouble:</p>
<ol class="steps"><li>Denominator = 0 → exclude. 1/(x − 2): x ≠ 2.</li><li>Even root of a negative → exclude. √(x − 3): x ≥ 3.</li></ol>
<div class="worked"><div class="wl">Slides, Example 3</div>g(x) = 3x² − x + 5. Replace every x with the new input in brackets:<br>g(z) = 3z² − z + 5<br>g(r²) = 3r⁴ − r² + 5<br>g(x + h) = 3(x + h)² − (x + h) + 5 = 3x² + 6hx + 3h² − x − h + 5</div>
<div class="tip"><b>Tip:</b> always put the input in brackets. f(−2) for f(x) = x² is (−2)² = 4, not −2² = −4.</div>`},
{t:'fun',g:'domrange',title:'Domain and range',html:`
<p><b>Domain</b> = every input x the function accepts. <b>Range</b> = every output y it can produce. Start with the domain: you are looking for inputs that <i>break</i> the formula.</p>
<table class="rt"><tr><th>If you see…</th><th>Rule</th><th>Example</th></tr>
<tr><td>A fraction</td><td>denominator ≠ 0</td><td>1/(x − 2) → x ≠ 2</td></tr>
<tr><td>An even root (√)</td><td>radicand ≥ 0</td><td>√(x − 3) → x ≥ 3</td></tr>
<tr><td>Both: root in a denominator</td><td>radicand &gt; 0 (strict)</td><td>1/√(x − 3) → x &gt; 3</td></tr>
<tr><td>Polynomial, odd root</td><td>no restriction</td><td>x² + 1, ∛x → all reals</td></tr></table>
<div class="worked"><div class="wl">Worked example: domain</div>f(x) = √(5 − 2x).<br>Need 5 − 2x ≥ 0 → −2x ≥ −5. Dividing by a <b>negative</b> flips the sign: x ≤ 5/2.<br>Domain: <b>x ≤ 5/2</b>, i.e. (−∞, 5/2].</div>
<p><b>Finding the range:</b> think about the lowest or highest output.</p>
<ol class="steps"><li><b>Parabola</b> a(x − h)² + k: the vertex gives the extreme. a &gt; 0 → y ≥ k. a &lt; 0 → y ≤ k.</li><li><b>√(…) + k</b> → y ≥ k. <b>−√(…) + k</b> → y ≤ k.</li><li><b>|…| + k</b> → y ≥ k. <b>−|…| + k</b> → y ≤ k.</li><li><b>a/(x − p) + k</b> → every y <i>except</i> k.</li><li><b>Lines and odd powers</b> → all real numbers.</li></ol>
<div class="worked"><div class="wl">Worked example: range</div>f(x) = −2(x + 1)² + 7. Vertex (−1, 7). a = −2 &lt; 0, so it opens down and 7 is the maximum.<br>Range: <b>y ≤ 7</b>.</div>
<p><b>Interval notation:</b> [ ] includes the end point (≥, ≤); ( ) excludes it (&gt;, &lt;) and is always used with ∞. x ≠ 3 is written (−∞, 3) ∪ (3, ∞).</p>
<div class="tip"><b>Common mistake:</b> shifting left or right (inside the bracket) changes the <b>domain</b> but never the range; shifting up or down changes the <b>range</b> but not the domain.</div>`},
{t:'fun',g:'special',title:'Special functions',html:`
<ol class="steps"><li><b>Constant:</b> h(x) = c. Every input gives c.</li><li><b>Polynomial:</b> f(x) = aₙxⁿ + … + a₀. Linear = degree 1, quadratic = degree 2.</li><li><b>Rational:</b> polynomial / polynomial; exclude zeros of the denominator.</li><li><b>Case-defined:</b> different rules on different intervals. Pick the rule first, then substitute.</li><li><b>Absolute value:</b> |x| = x if x ≥ 0, −x if x < 0.</li><li><b>Factorial:</b> n! = 1·2·…·n, and 0! = 1.</li></ol>
<div class="worked"><div class="wl">Worked example</div>f(x) = x + 1 if x < 0 and x² if x ≥ 0. f(−3) uses the first rule: −2. f(3) uses the second: 9.</div>
<div class="worked"><div class="wl">Factorials</div>5!/3! = (5·4·3!)/3! = 20. Cancel before multiplying out.</div>`},
{t:'fun',g:'combo',title:'Combining and composing functions',html:`
<p>(f + g)(x) = f(x) + g(x), (f − g)(x) = f(x) − g(x), (fg)(x) = f(x)g(x), (f/g)(x) = f(x)/g(x) with g(x) ≠ 0.</p>
<p><b>Composition:</b> (f ∘ g)(x) = f(g(x)). Work <b>inside out</b>: apply g first, then f.</p>
<div class="worked"><div class="wl">Slides, Example 1</div>f(x) = 3x − 1, g(x) = x² + 3x<br>(f + g)(x) = x² + 6x − 1<br>(f − g)(x) = −x² − 1<br>(fg)(x) = 3x³ + 8x² − 3x</div>
<div class="worked"><div class="wl">Slides, Example 3</div>f(x) = √x, g(x) = x + 1<br>(f ∘ g)(x) = f(x + 1) = √(x + 1)<br>(g ∘ f)(x) = g(√x) = √x + 1. Order matters!</div>
<div class="tip"><b>Common mistake:</b> in (f − g)(x), the minus applies to every term of g. Use brackets.</div>`},
{t:'fun',g:'inverse',title:'Inverse functions',html:`
<p>A function is <b>one-to-one</b> if different inputs always give different outputs. Only one-to-one functions have an inverse f⁻¹, which undoes f: f⁻¹(f(x)) = x.</p>
<ol class="steps"><li>Write y = f(x).</li><li>Swap x and y.</li><li>Solve for y. That y is f⁻¹(x).</li></ol>
<div class="worked"><div class="wl">Worked example</div>f(x) = 4x − 3. y = 4x − 3 → x = 4y − 3 → y = (x + 3)/4. So <b>f⁻¹(x) = (x + 3)/4</b>.<br>Check: f(f⁻¹(5)) = f(2) = 5 ✓</div>
<p>For a linear function f(x) = ax + b, the inverse is (x − b)/a. If f is one-to-one, the equation f(x) = 0 has the unique solution x = f⁻¹(0).</p>
<div class="tip"><b>Note:</b> f⁻¹(x) is not 1/f(x).</div>`},
{t:'fun',g:'graph',title:'Intercepts and symmetry',html:`
<p><b>Intercepts:</b> x-intercept → set y = 0. y-intercept → set x = 0.</p>
<div class="worked"><div class="wl">Slides, Example 1</div>y = 2x + 3. x = 0 gives y = 3 → (0, 3). y = 0 gives x = −3/2 → (−3/2, 0).</div>
<p><b>Symmetry tests</b> (the test passes if you get an equivalent equation):</p>
<table class="rt"><tr><th>Symmetric about</th><th>Replace</th><th>Example</th></tr>
<tr><td>y-axis</td><td>x with −x</td><td>y = x², y = 1 − x⁴</td></tr>
<tr><td>x-axis</td><td>y with −y</td><td>x = y²</td></tr>
<tr><td>origin</td><td>x with −x and y with −y</td><td>y = x³</td></tr>
<tr><td>line y = x</td><td>swap x and y</td><td>x² + y² = 1</td></tr></table>
<div class="tip"><b>Shortcut:</b> only even powers of x → y-axis symmetry. Only odd powers and no constant → origin symmetry. A non-zero function of x can't be x-axis symmetric (it would fail the vertical line test).</div>`},
{t:'fun',g:'trans',title:'Translations and reflections',html:`
<p>Know the six basic graphs: y = x, y = x², y = x³, y = |x|, y = √x, y = 1/x. Then transform them (c > 0):</p>
<table class="rt"><tr><th>Equation</th><th>Effect</th></tr>
<tr><td>y = f(x) + c</td><td>up c</td></tr><tr><td>y = f(x) − c</td><td>down c</td></tr>
<tr><td>y = f(x − c)</td><td>right c</td></tr><tr><td>y = f(x + c)</td><td>left c</td></tr>
<tr><td>y = −f(x)</td><td>reflect about x-axis</td></tr><tr><td>y = f(−x)</td><td>reflect about y-axis</td></tr></table>
<div class="worked"><div class="wl">Slides, Example 1</div>y = (x − 1)³ is y = x³ moved <b>1 unit right</b>.</div>
<div class="tip"><b>Remember:</b> changes inside the bracket go the “wrong” way: (x − 1) moves right, (x + 1) moves left.</div>`},
{t:'lin',g:'lines',title:'Slope and equations of lines',html:`
<p><b>Slope</b> m = (y₂ − y₁)/(x₂ − x₁) = rise / run. In business it's a rate: e.g. dollars per thousand units.</p>
<table class="rt"><tr><th>Form</th><th>Equation</th></tr>
<tr><td>Point-slope</td><td>y − y₁ = m(x − x₁)</td></tr><tr><td>Slope-intercept</td><td>y = mx + b</td></tr>
<tr><td>General linear</td><td>Ax + By + C = 0</td></tr><tr><td>Horizontal</td><td>y = b (slope 0)</td></tr><tr><td>Vertical</td><td>x = a (slope undefined)</td></tr></table>
<div class="worked"><div class="wl">Slides, Example 3</div>Line through (−3, 8) and (4, −2):<br>m = (−2 − 8)/(4 + 3) = −10/7<br>y − 8 = −10/7 (x + 3) → 7y − 56 = −10x − 30 → <b>10x + 7y − 26 = 0</b></div>
<div class="worked"><div class="wl">Slides, Example 5</div>y = 5(3 − 2x) = −10x + 15: slope −10, y-intercept 15.</div>`},
{t:'lin',g:'parperp',title:'Parallel and perpendicular lines',html:`
<p><b>Parallel:</b> same slope. <b>Perpendicular:</b> slopes multiply to −1, so m₂ = −1/m₁ (flip and change sign).</p>
<div class="worked"><div class="wl">Slides, Example 9</div>Through (3, −2), relative to y = 3x + 1:<br>Parallel: slope 3 → y + 2 = 3(x − 3) → <b>y = 3x − 11</b><br>Perpendicular: slope −1/3 → y + 2 = −1/3(x − 3) → <b>y = −x/3 − 1</b></div>
<div class="tip"><b>Check:</b> 3 × (−1/3) = −1 ✓</div>`},
{t:'lin',g:'linapp',title:'Linear functions in business',html:`
<p>A <b>linear function</b> is f(x) = ax + b. Two known values are enough to find it: compute the slope, then use point-slope.</p>
<div class="worked"><div class="wl">Slides, Example 5</div>f(−2) = 6, f(1) = −3 → m = (−3 − 6)/(1 + 2) = −3 → y + 3 = −3(x − 1) → <b>f(x) = −3x</b>.</div>
<p><b>Demand curves</b> slope down (higher price → less demanded). <b>Supply curves</b> slope up (higher price → more supplied). Price p goes on the vertical axis, quantity q on the horizontal.</p>
<div class="worked"><div class="wl">Slides, Example 1</div>100 lb of material; A uses 4 lb/unit, B uses 2 lb/unit: 4x + 2y = 100 → y = 50 − 2x.</div>`},
{t:'lin',g:'systems',title:'Systems of equations',html:`
<p>Two lines can cross once (<b>one solution</b>), be parallel (<b>no solution</b>) or be the same line (<b>infinitely many</b>).</p>
<ol class="steps"><li><b>Elimination by addition:</b> multiply equations so one variable has opposite coefficients, add, solve, substitute back.</li><li><b>Substitution:</b> solve one equation for a variable, plug it into the other. Best for <b>nonlinear</b> systems.</li></ol>
<div class="worked"><div class="wl">Worked example</div>x + y = 5 and 2x − y = 1. Add: 3x = 6 → x = 2. Then y = 3.</div>
<div class="worked"><div class="wl">Slides, 3.4 Example 1</div>x² − 2x + y − 7 = 0 and 3x − y + 1 = 0. From eq.2, y = 3x + 1. Substitute: x² + x − 6 = 0 → x = −3 or 2 → points (−3, −8) and (2, 7).</div>
<div class="tip"><b>Signals:</b> if elimination gives 0 = 0 → infinitely many; if it gives 0 = 5 (false) → no solution.</div>`},
{t:'lin',g:'equil',title:'Market equilibrium',html:`
<p>The <b>equilibrium point</b> is where supply = demand. Set the two price equations equal and solve for q, then find p.</p>
<div class="worked"><div class="wl">Slides, 3.5 Example 1</div>Supply p = (3/100)q + 2, demand p = −(7/100)q + 12.<br>(10/100)q = 10 → <b>q = 100, p = $5</b>.<br>With a $1.50 tax on the supplier, supply becomes p = (3/100)q + 3.50 → (10/100)q = 8.5 → <b>q = 85, p = $6.05</b>.</div>
<div class="tip"><b>Intuition:</b> a tax on suppliers shifts supply up. Price rises, quantity falls, and consumers pay part of the tax ($1.05 of the $1.50 here).</div>`},
{t:'lin',g:'breakeven',title:'Break-even, profit and loss',html:`
<ol class="steps"><li>Total revenue TR = price × q</li><li>Total cost TC = (variable cost per unit) × q + fixed cost</li><li>Profit = TR − TC</li><li>Break-even: TR = TC (profit 0)</li></ol>
<div class="worked"><div class="wl">Slides, 3.5 Example 3</div>p = $8, FC = $5000, VC = 22/9 per unit.<br>TR = TC: 8q = (22/9)q + 5000 → (50/9)q = 5000 → <b>q = 900, TR = $7200</b>.<br>At 1800 units: profit = (50/9)(1800) − 5000 = <b>$5000</b>.<br>At 450 units: (50/9)(450) − 5000 = <b>−$2500</b> (a loss).<br>Profit of $10 000 needs (50/9)q = 15 000 → <b>q = 2700</b>.</div>
<div class="tip"><b>Shortcut:</b> break-even q = fixed cost / (price − variable cost per unit).</div>`},
{t:'lin',g:'parab',title:'Quadratic functions and parabolas',html:`
<p>f(x) = ax² + bx + c graphs as a <b>parabola</b>. Steps to sketch:</p>
<ol class="steps"><li>Direction: a > 0 opens up (minimum), a < 0 opens down (maximum).</li><li>Vertex: x = −b/(2a); plug in to get y.</li><li>y-intercept: (0, c).</li><li>x-intercepts: solve ax² + bx + c = 0.</li><li>Axis of symmetry: the vertical line through the vertex.</li></ol>
<div class="worked"><div class="wl">Slides, 3.6</div>y = −x² − 4x + 12: a = −1 (opens down). Vertex x = −(−4)/(2·−1) = −2, y = 16 → (−2, 16). y-intercept 12. x-intercepts: −(x + 6)(x − 2) = 0 → −6 and 2.</div>
<div class="tip"><b>Business use:</b> maximum revenue or profit is at the vertex of a downward parabola.</div>`},
{t:'lin',g:'elast',title:'Elasticity of demand',html:`
<p>Point elasticity of demand: <b>η = (p/q) · (dq/dp)</b>. For linear demand q = A − Bp, dq/dp = −B.</p>
<table class="rt"><tr><th>|η|</th><th>Name</th><th>Raise price → revenue</th></tr><tr><td>&gt; 1</td><td>Elastic</td><td>falls</td></tr><tr><td>= 1</td><td>Unit elastic</td><td>unchanged (revenue max)</td></tr><tr><td>&lt; 1</td><td>Inelastic</td><td>rises</td></tr></table>
<div class="worked"><div class="wl">Worked example</div>q = 100 − 2p at p = 20: q = 60, η = (20/60)(−2) = −0.67. |η| < 1 → <b>inelastic</b>. A 1% price rise cuts quantity by only 0.67%.</div>`},
];
